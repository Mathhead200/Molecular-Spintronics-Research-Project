var searchData=
[
  ['udcexception_0',['UDCException',['../d7/d91/classudc_1_1_u_d_c_exception.html',1,'udc']]]
];
