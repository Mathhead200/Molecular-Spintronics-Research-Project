var searchData=
[
  ['vector_0',['Vector',['../d8/dd4/classudc_1_1_vector.html#ae04c82f1475c537a4c31b2489e088134',1,'udc::Vector::Vector(double x, double y, double z)'],['../d8/dd4/classudc_1_1_vector.html#a77d31b8c68c2b5cf617f055c89c32a61',1,'udc::Vector::Vector(double x, double y)'],['../d8/dd4/classudc_1_1_vector.html#a8c4d5f7db83f0cef1c07b4b42f78e0e3',1,'udc::Vector::Vector()']]]
];
