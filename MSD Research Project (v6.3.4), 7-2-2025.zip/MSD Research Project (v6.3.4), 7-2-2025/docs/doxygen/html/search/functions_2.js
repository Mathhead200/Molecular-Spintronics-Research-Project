var searchData=
[
  ['begin_0',['begin',['../da/d97/classudc_1_1_molecule_1_1_node_iterable.html#a93ca9f19d78899a40883db494030f979',1,'udc::Molecule::NodeIterable::begin()'],['../d9/d00/classudc_1_1_molecule_1_1_edge_iterable.html#a6ad09c81e1ffd3a9d71ba1db9073e6cc',1,'udc::Molecule::EdgeIterable::begin()'],['../d1/d55/classudc_1_1_m_s_d.html#afb91b037de5315bfde0159ee591267a3',1,'udc::MSD::begin()']]],
  ['bread_1',['bread',['../d5/d44/namespaceudc.html#a51cb94811213523405b27e375b7a1b33',1,'udc::bread(void *destination, size_t dSize, const unsigned char *&amp;buffer)'],['../d5/d44/namespaceudc.html#a6f17d107671fb6c3d5e2044d346e45c5',1,'udc::bread(T &amp;destination, const unsigned char *&amp;buffer)']]],
  ['bwrite_2',['bwrite',['../d5/d44/namespaceudc.html#a1e040d8326f2ad3b600f8f66a8de6305',1,'udc::bwrite(const void *source, size_t sSize, unsigned char *&amp;buffer)'],['../d5/d44/namespaceudc.html#a0a7d84b783b302ce21db57fd497817d0',1,'udc::bwrite(const T &amp;source, unsigned char *&amp;buffer)']]]
];
