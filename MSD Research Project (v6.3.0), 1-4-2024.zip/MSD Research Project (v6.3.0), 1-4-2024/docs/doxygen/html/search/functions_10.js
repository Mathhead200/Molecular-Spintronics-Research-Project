var searchData=
[
  ['udcexception_0',['UDCException',['../d7/d91/classudc_1_1_u_d_c_exception.html#a60f9a75be4d8880a5521dc50d4df05f7',1,'udc::UDCException']]]
];
