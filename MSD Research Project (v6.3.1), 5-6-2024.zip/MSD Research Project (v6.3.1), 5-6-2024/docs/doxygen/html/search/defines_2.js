var searchData=
[
  ['udc_5fmsd_5fversion_0',['UDC_MSD_VERSION',['../db/db5/_m_s_d_8h.html#aed08a6e3241c31dccac6a5bbbe306447',1,'MSD.h']]]
];
