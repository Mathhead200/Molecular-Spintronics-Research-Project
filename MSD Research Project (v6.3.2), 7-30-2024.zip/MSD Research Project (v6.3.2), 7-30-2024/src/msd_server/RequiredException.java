package msd_server;

public class RequiredException extends Exception {

}
