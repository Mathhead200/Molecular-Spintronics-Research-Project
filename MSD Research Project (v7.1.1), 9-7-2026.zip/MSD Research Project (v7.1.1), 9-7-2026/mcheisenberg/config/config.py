from __future__ import annotations
from ..util import StrJoiner, is_pow2, MASM_RESERVED_KEYWORDS, EDGE_PARAMETERS, NODE_PARAMETERS
from ..build import VisualStudio
from ..runtime import Runtime
from collections import defaultdict
from collections.abc import Sequence
from copy import deepcopy
from datetime import datetime
from importlib import resources
from math import ceil, log2
from subprocess import CalledProcessError
from tempfile import mkstemp
from tqdm import tqdm
from typing import Generic, Optional, TypeVar, TypedDict, TYPE_CHECKING
import os
import re
if TYPE_CHECKING:
	from collections.abc import Callable, Collection, Iterable

type vec = tuple[float, float, float]

class NodeParameters(TypedDict, total=False):
	spin: vec   # inital spin (None = random)
	flux: vec   # inital flux
	S: float    # spin magnatude
	F: float    # max flux magnitude
	kT: float   # temperature
	B: vec      # external magnetic field
	A: vec      # anisotropy
	Je0: float  # local (r=0) spin-flux exchange coupling constant

class EdgeParameters(TypedDict, total=False):
	J: float    # Heisenberg exchange coupling constant
	Je1: float  # neighboring (r=1) spin-flux exchange coupling constant
	Jee: float  # neighboring (r=1) flux-flux exchange coupling constant
	b: float    # biquadratic coupling
	D: vec      # Dzyaloshinsky–Moriya interaction

class NodeAndEdgeParameters(NodeParameters, EdgeParameters):
	pass

class ProgramParameters(TypedDict):
	t_eq: Optional[int]
	simCount: int
	freq: Optional[int]
	seed: Optional[list[int]]
	prng: str  # which algorithm?

Index = TypeVar("Index")    # type of node indicies; e.g., int, or tuple[int]
Region = TypeVar("Region")  # type of region names; e.g. str

class _Config(Generic[Index, Region], TypedDict, total=False):
	type Node = Index
	type Edge = tuple[Node, Node]

	type Nodes = Collection[Node]
	type Edges = Collection[Edge]

	nodes: Nodes
	edges: Edges  # tuple elemenets must be elements of (in) self.nodes
	mutableNodes: Nodes  # must be a subset of self.nodes
	
	globalParameters: NodeAndEdgeParameters

	regions: dict[Region, Nodes]
	regionNodeParameters: dict[Region, NodeParameters]
	regionEdgeParameters: dict[tuple[Region, Region], EdgeParameters]
	
	localNodeParameters: dict[Node, NodeParameters]
	localEdgeParameters: dict[Edge, EdgeParameters]

	programParameters: ProgramParameters

	# TODO: specify which parameters may change durring execution.
	#	Use this information to allow for optimization on constant parameters.
	#	e.g. 0: remove;  1: skip load and mul;  -1: _vneg
	variableParamters: NodeAndEdgeParameters  # set

	nodeId: Callable[[Node], str]      # returned str must conform to C identifier spec.
	regionId: Callable[[Region], str]  # returned str must conform to C identifier spec. Must be able to handle None as input.

class Config:
	ALLOWED_NODE_PARAMETERS = set(NODE_PARAMETERS)
	ALLOWED_EDGE_PARAMETERS = set(EDGE_PARAMETERS)
	ALLOWED_PRGM_PARAMETERS = { "prng", "seed" }
	RESERVED_IDS = {
		# segments
		"NODES", "EDGES", "REGIONS", "EDGE_REGIONS", "GLOBAL_NODE", "GLOBAL_EDGE",
		# ASM identifiers
		*NODE_PARAMETERS, *EDGE_PARAMETERS,             # globals
		"nodes", "regions", "edges", "edge_regions",    # arrays
		"kTref", "Sref", "Fref", "SFref", "prng_state",
		# procedures
		"metropolis", "seed", "randomize", "mutable_state"
	}

	@staticmethod
	def validate_id(id, err_prefix: str="Node or region"):
		id = str(id)
		if id.startswith("OFFSETOF"):
			raise ValueError(f"{err_prefix} {id} reserved: starts with OFFSETOF")
		if id.startswith("SIZEOF"):
			raise ValueError(f"{err_prefix} {id} reserved: starts with SIZEOF")
		if id.endswith("COUNT"):
			raise ValueError(f"{err_prefix} {id} reserved: ends with COUNT")
		if id.startswith("deltaU"):
			raise ValueError(f"{err_prefix} {id} reserved: starts with deltaU")
		if id in Config.ALLOWED_NODE_PARAMETERS | Config.ALLOWED_EDGE_PARAMETERS:
			raise ValueError(f"{err_prefix} {id} reserved: matches parameter name")
		if id in Config.RESERVED_IDS:
			raise ValueError(f"{err_prefix} {id} reserved")
		if id.upper() in MASM_RESERVED_KEYWORDS:  # case insensitive
			raise ValueError(f"{err_prefix} {id} reserved: MASM keyword (directive, instruction, etc.)")
	
	@staticmethod
	def validate_nid(nid):
		err_prefix = "Node"
		Config.validate_id(nid, err_prefix)
		if not re.fullmatch(r"\w+", nid):
			raise ValueError(f"{err_prefix} {nid} invalid identifier. (e.g. Must not include spaces.)")

	@staticmethod
	def validate_rid(rid):
		err_prefix = "Region"
		Config.validate_id(rid, err_prefix)
		if not re.fullmatch(r"[A-Za-z_]\w*", rid):
			raise ValueError(f"{err_prefix} {rid} invalid identifier. (e.g. Must not include spaces or start with a digit.)")

	@staticmethod
	def asm_float(value: float) -> str:
		num = f"{value:.17f}".rstrip("0")
		if num.endswith("."):  num += "0"
		return num

	@staticmethod
	def asm_floats(values: Iterable) -> tuple[str]:
		return (Config.asm_float(val) for val in values)

	def __init__(self, **kw):
		self.__dict__ = _Config(*kw)
		if "nodeId" not in self.__dict__:
			self.nodeId = lambda node: str(node)
		if "regionId" not in self.__dict__:
			self.regionId = lambda region: str(region)
		# fields set durring compilation
		self.localNodeKeys: set[str] = None    # set[str]: which localNodeParameters are being used?
		self.localEdgeKeys: set[str] = None    # set[str]: which localEdgeParameters are being used?
		self.regionNodeKeys: set[str] = None   # set[str]: which regionNodeParameters are being used?
		self.regionEdgeKeys: set[str] = None   # set[str]: which regionEdgeParameters are being used?
		self.globalKeys: set[str] = None       # set[str]: which globalParameters are being used?
		self.allKeys: set[str] = None          # set[str]: which parameter keys are being used anywhere in the model? (union of all of keys sets.)
		self.immutableNodes: list = None  # list[Node]: disjoint of self.nodes - self.mutableNodes
		self.nodeIndex: dict = None       # map: (Node) -> (int) index in ASM nodes array
		self.edgeIndex: dict = None       # map: (Edge) -> (int) index in ASM edges array
		self.regionCombos: list[tuple] = None  # list[Edge] containing all region combos of 1 or 2 regions. Counter-part to self.regions, but for edges.
		self.constParameters: set[str] = None  # set[str in NodeAndEdgeParameters.keys()] which will not change durring runtime leading to optimizations
		# ASM "EQU" defines
		self.OFFSETOF_SPIN:        int = None  # node
		self.OFFSETOF_FLUX:        int = None
		self.OFFSETOF_B:           int = None
		self.OFFSETOF_dB:          int = None
		self.OFFSETOF_A:           int = None
		self.OFFSETOF_S:           int = None
		self.OFFSETOF_F:           int = None
		self.OFFSETOF_kT:          int = None
		self.OFFSETOF_Je0:         int = None
		self.OFFSETOF_dkT:         int = None
		self.SIZEOF_NODE:          int = None
		self.MUTABLE_NODE_COUNT:   int = None
		self.IMMUTABLE_NODE_COUNT: int = None
		self.NODE_COUNT:           int = None
		self.OFFSETOF_REGION_B:    int = None  # region
		self.OFFSETOF_REGION_dB:   int = None
		self.OFFSETOF_REGION_A:    int = None
		self.OFFSETOF_REGION_S:    int = None
		self.OFFSETOF_REGION_F:    int = None
		self.OFFSETOF_REGION_kT:   int = None
		self.OFFSETOF_REGION_Je0:  int = None
		self.OFFSETOF_REGION_dkT:  int = None
		self.SIZEOF_REGION:        int = None
		self.REGION_COUNT:         int = None
		self.OFFSETOF_J:           int = None  # edge
		self.OFFSETOF_Je1:         int = None
		self.OFFSETOF_Jee:         int = None
		self.OFFSETOF_b:           int = None
		self.OFFSETOF_D:           int = None
		self.SIZEOF_EDGE:          int = None
		self.EDGE_COUNT:           int = None
		self.OFFSETOF_REGION_J:    int = None  # edge region
		self.OFFSETOF_REGION_Je1:  int = None
		self.OFFSETOF_REGION_Jee:  int = None
		self.OFFSETOF_REGION_b:    int = None
		self.OFFSETOF_REGION_D:    int = None
		self.SIZEOF_EDGE_REGION:   int = None
		self.EDGE_REGION_COUNT:    int = None

	def __repr__(self) -> str:
		return str(self.__dict__)
	
	@staticmethod
	def innerKeys(parameters: dict) -> set[str]:
		"""
		Computes a set of all the local/region parameter keys used at least
		once across all nodes/edges/regions in the system. e.g.
		<pre>
			msd = Config()
			# ...
			msd.localNodeParameters = {
				node1 : {kT: 0.1},
				node2 : {B: (0, 0.1, 0), F: 1}
			}
			msd.regionNodeParameters = {
				regionA : {kT: 0.2},
				regionB : {A: (0, 0, 0.1), S: 0.5}
			}
			msd.regionEdgeParameters = {
				edge1 : {J: -0.5},
				edge2 : {b: 0.25}
			}
			print(Config.innerKeys(self.localNodeParameters))   # {kT, B, F}
			print(Config.innerKeys(self.regionNodeParameters))  # {kT, A, S}
			print(Config.innerKeys(sele.regionEdgeParameters))  # {J, b}
		</pre>
		"""
		keys = set()
		for innerDict in parameters.values():
			keys |= innerDict.keys()
		return keys
	
	def calcImmutableNodes(self) -> Iterable:
		"""
		Computes all immutable nodes by calculating the disjoint of
		<code>self.nodes - self.mutableNodes</code>.
		The returned nodes will be in the same order they appear in
		<code>self.nodes</code>.
		"""
		M = set(self.mutableNodes)
		return [n for n in self.nodes if n not in M]

	def calcAllRegionCombos(self) -> list[tuple]:
		"""
		Computes all possible 1 or 2 region combinations. e.g.
		<pre>
		msd = Config()
		# ...
		msd.regions = {
			A:  # [... nodes ...],
			B:  # [... nodes ...],
			C:  # [... nodes ...],
		}
		print(msd.calcRegionCombos())
		# Output: [
		#	(A, None), (A, A), (A, B), (A, C), (None, A),
		#	(B, None), (B, A), (B, B), (B, C), (None, B),
		#	(C, None), (C, A), (C, B), (C, C), (None, C),
		# ]
		</pre>
		Notes:
		* Some of these combinatorically possible regions may contain zero edges.
		* (None, None) edges can be convered by self.globalParameters
		"""
		combos = []
		for src in self.regions:
			combos.append((src, None))
			for dest in self.regions:
				combos.append((src, dest))
			combos.append((None, src))
		return combos
	
	def calcFluxMode(self) -> bool:
		"""
		Returns True if any parameters are set which would require flux
		vectors for each node's state. Otherwise, False.
		Preconditon:
			* Must be called after self.__keys sets are initialized.
		"""
		return "F" in self.globalKeys + self.regionNodeKeys + \
			self.regionEdgeKeys + self.localNodeKeys + self.localEdgeKeys

	def getRegions(self, node) -> list:
		""" Get the list of all regions containing this node. May be empty list []. """
		# TODO: Optimize. This function is now used by the runtime as well.
		#	subnodes data structure is not nessesarily optimized for the "in" operation.
		return [label for label, subnodes in self.regions.items() if node in subnodes]
	
	def getRegionCombos(self, edge) -> list:
		"""
		Get the list of all (region, region) tuples possible for this edge.
		May be empty list [].
		Tuple elements may contain a None (e.g. (None, regionA)) exactly when one node is in no regions.
		"""
		R0 = self.getRegions(edge[0])
		R1 = self.getRegions(edge[1])
		
		if len(R0) == 0 and len(R1) == 0:
			return []
		if len(R0) == 0:
			return [(None, r1) for r1 in R1]
		if len(R1) == 0:
			return [(r0, None) for r0 in R0]
		# else:
		return [(r0, r1) for r0 in R0 for r1 in R1]
	
	def getAllRegionNodeParameterValues(self, node, param) -> list[tuple]:
		"""
		Find the value(s) defined at the region level of this parameter and node.
		Value is returned as a list of tuples: [(value, region), ...].
		The list may be empty if this parameter is not defined at the region
			level of any regions this node is in.
		Or it may have multiple values if multiple regions contain this node,
			define this same parameter. This should be okay as long as all the
			regions agree on the same value. Otherwise, th parameter value is
			ambiguous for this node.
		"""
		values = []
		for region in self.getRegions(node):
			regionParams = self.regionNodeParameters.get(region, {})
			if param in regionParams:
				values.append((regionParams[param], region))
		return values
	
	def getAllRegionEdgeParameterValues(self, edge, param) -> list[tuple]:
		""" 
		Similar to getAllRegionNodeParameterValues, but returned tuples contain
		[(value, combo), ...] where combo = tuple(region0, region1).
		"""
		values = []
		for combo in self.getRegionCombos(edge):
			regionParams = self.regionEdgeParameters.get(combo, {})
			if param in regionParams:
				values.append((regionParams[param], combo))
		return values

	def getUnambiguousRegionNodeParameter(self, node, param):
		"""
		Similar to getAllRegionNodeParameterValues, except
		(1) only returns one tuple, (value, region), not a list, and instead
		(2) raises an exception if the value is ambiguous.
		Returns (None, None) if the list of region values is empty.
		"""
		values = self.getAllRegionNodeParameterValues(node, param)
		if len(values) == 0:
			return None, None
		# all the values should be equal to the first value (transative property of equality)
		value, region = values[0]
		collisions = []
		for v, r in values:
			if v != value:
				collisions.append((v, r))
		if len(collisions) != 0:
			raise ValueError(
				f"For node {self.nodeId(node)}, {param} is ambiguously defined in multiple regions: {[r for _, r in values]}." + \
				f"{param} is defined as {value} in {region}, but also defined as {[f"{v} in {r}" for v, r in collisions]}." )
		return value, region
	
	def getUnambiguousRegionEdgeParameter(self, edge, param):
		""" 
		Similar to getUnambiguousRegionNodeParameter, but returned tuple contains
		(value, combo) where combo = tuple(region0, region1), or (None, None).
		"""
		values = self.getAllRegionEdgeParameterValues(edge, param)
		if len(values) == 0:
			return (None, None)
		# all the values should be equal to the first value (transative property of equality)
		value, combo = values[0]
		collisions = []
		for v, c in values:
			if v != value:
				collisions.append((v, c))
		if len(collisions) != 0:
			raise ValueError(
				f"For edge {self.nodeId(edge[0])} -> {self.nodeId(edge[1])}, {param} is ambiguously defined in multiple edge-regions: {[c for _, c in values]}." + \
				f"{param} is defined as {value} in {combo}, but also dedfined as {[f"{v} in {c}" for v, c in collisions]}." )
		return value, combo
	
	def hasNodeParameter(self, node, param) -> bool:
		"""
		Return True if this node has a definiton for the parameter at some level
		(local, region, or global). Otherwise, False.
		"""
		return param in self.globalKeys or \
			param in self.localNodeParameters.get(node, {}) or \
			len(self.getAllRegionNodeParameterValues(node, param)) != 0
	
	def hasEdgeParameter(self, node, param) -> bool:
		"""
		Return True if an edge connected to this node has a definiton for the
		parameter at some level (local, region, or global). Otherwise, False.
		"""
		edges = [edge for edge in self.edges if node in edge]
		combos = [combo for edge in edges for combo in self.getRegionCombos(edge)]
		return param in self.globalKeys \
			or any(param in self.localEdgeParameters.get(edge, {}) for edge in edges) \
			or any(param in self.regionEdgeParameters.get(combo, {}) for combo in combos)
	
	def hasFlux(self, node):  return self.hasNodeParameter(node, "F")
	def hasJ(self, node):     return self.hasEdgeParameter(node, "J")
	def hasJe0(self, node):   return self.hasNodeParameter(node, "Je0")
	def hasJe1(self, node):   return self.hasEdgeParameter(node, "Je1")
	def hasJee(self, node):   return self.hasEdgeParameter(node, "Jee")
	def hasA(self, node):     return self.hasNodeParameter(node, "A")
	def hasB(self, node):     return self.hasNodeParameter(node, "B")
	def hasb(self, node):     return self.hasEdgeParameter(node, "b")
	def hasD(self, node):     return self.hasEdgeParameter(node, "D")

	def connections(self, node) -> list:
		""" List of edges containing (i.e. connected to) a node. """
		return [edge for edge in self.edges if node in edge]
	
	@staticmethod
	def neighbor(node, edge) -> tuple:
		"""
		Return (neighbor, direction):
			direction = 1: forward edge (node -> neighbor)
			direction = -1: backward edge (neightbor -> node)
			direction = 0: self-loop (node -> node)
		or (None, None) if edge isn't connected to node.
		"""
		if node == edge[0]:
			return (edge[1], 1 if node != edge[1] else 0)
		if node == edge[1]:
			return (edge[0], -1)
		return (None, None)

	def getNodeConst(self, node, k: str) -> float:
		"""	If parameter k is a const, return its value for the given node.
			Returns None if k isn't defined or if k isn't constant.
		"""
		if k not in self.constParameters:
			return None
		v = self.localNodeParameters[node].get(k, None)
		if v is not None:
			return v
		v, _ = self.getUnambiguousRegionNodeParameter(node, k)
		if v is not None:
			return v
		return self.globalParameters.get(k, None)

	def getEdgeConst(self, edge, k: str) -> float:
		"""	If parameter k is a const, return its value for the given edge.
			Returns None if k isn't defined or if k isn't constant.
		"""
		if k not in self.constParameters:
			return None
		v = self.localEdgeParameters[edge].get(k, None)
		if v is not None:
			return v
		v, _ = self.getUnambiguousRegionEdgeParameter(edge, k)
		if v is not None:
			return v
		return self.globalParameters.get(k, None)
	
	def precompile(self, progress_bars: bool=False, pbar_args: dict={}) -> tuple[str, list]:
		"""
		Validate, update Config object fields, and generate ASM.
		Do everything except run the assembler and linker.
		Return: src (ASM), exports (DEF)
		"""

		# Check for and fix missing required attributes;
		if "nodes"                not in self.__dict__:  self.nodes = []
		if "mutableNodes"         not in self.__dict__:  self.mutableNodes = self.nodes
		if "edges"                not in self.__dict__:  self.edges = []
		if "regions"              not in self.__dict__:  self.regions = {}
		if "localNodeParameters"  not in self.__dict__:  self.localNodeParameters = {}
		if "localEdgeParameters"  not in self.__dict__:  self.localEdgeParameters = {}
		if "regionNodeParameters" not in self.__dict__:  self.regionNodeParameters = {}
		if "regionEdgeParameters" not in self.__dict__:  self.regionEdgeParameters = {}
		if "globalParameters"     not in self.__dict__:  self.globalParameters = { "S": 1.0 }
		if "variableParameters"   not in self.__dict__:  self.variableParameters = set()
		if "programParameters"    not in self.__dict__:  self.programParameters = {}
		if "debug"                not in self.__dict__:  self.debug = set()

		if "prng" not in self.programParameters:
			self.programParameters["prng"] = "xoshiro256**"

		# aliases
		prng = self.programParameters["prng"]
		seed = self.programParameters.get("seed", None)
		if seed is not None and seed is not isinstance(seed, Sequence):
			seed = [seed]  # one element list
		asm_float  = Config.asm_float   # function
		asm_floats = Config.asm_floats  # function

		DEBUG_OPTIONS = { "deltaU_ret_dump" }
		_unrecognized_debug_options = self.debug - DEBUG_OPTIONS
		if len(_unrecognized_debug_options) != 0:
			raise ValueError(f"Urecognized debug options: {_unrecognized_debug_options}")

		tqdm_check = tqdm(
			total= 3 + len(self.nodes) + len(self.regions) + len(self.edges) + len(self.localNodeParameters) + \
				len(self.localEdgeParameters) + len(self.regionNodeParameters) + len(self.regionEdgeParameters) + \
				len(self.globalParameters) + len(self.programParameters) + 1 + len(seed) if seed is not None else 0 + \
				1 + len(self.localNodeParameters) + len(self.localEdgeParameters) + len(self.regionNodeParameters) + \
				len(self.regionEdgeParameters) + 2*(len(self.mutableNodes) + len(self.regions) + 1),
			desc="[Compiling] Validating config",
			**pbar_args
		) if progress_bars else None
		def tqdm_check_update(n=1):
			if tqdm_check is not None:  tqdm_check.update(n)
		# CHECK: at least one node
		if len(self.nodes) == 0:
			raise ValueError("Must define at least one node.")
		tqdm_check_update()

		# CHECK: No duplicate nodes or edges (TODO: allow duplicate edges?)
		if len(set(self.nodes)) != len(self.nodes):
			raise ValueError("Duplicate nodes.")
		tqdm_check_update()
		if len(set(self.edges)) != len(self.edges):
			raise ValueError("Duplicate edges.")
		tqdm_check_update()

		# CHECK: Make sure all node and region names are valid identifiers for ASM output
		for n in self.nodes:
			nid = self.nodeId(n)
			Config.validate_nid(nid)
			tqdm_check_update()
		for r in self.regions:
			rid = self.regionId(r)
			Config.validate_rid(rid)
			tqdm_check_update()

		# CHECK: Do all nodes referenced in self.edges actually exist in self.nodes?
		for edge in self.edges:
			if type(edge) is not tuple:
				raise ValueError(f"All edges must be tuples: type={type(edge)} for edge {edge}")
			if len(edge) != 2:
				raise ValueError(f"All edges must have exactly 2 nodes: len={len(edge)} for edge {edge}")
			for node in edge:
				if node not in self.nodes:
					raise KeyError(f"All nodes referenced in model.edges must exist in model.nodes: Couldn't find node {node} referenced in edge {edge}")
			tqdm_check_update()

		# CHECK: Are all parameters (i.e. dict keys) supported by the program and
		# 	in the correct dicts (i.e. edge parameter in node dict)?
		for n, p in self.localNodeParameters.items():
			for k, v in p.items():
				if k not in Config.ALLOWED_NODE_PARAMETERS:
					if k in Config.ALLOWED_EDGE_PARAMETERS:
						raise KeyError(f'{k} is an edge parameters and unsupported in localNodeParameters[{n}]["{k}"]. Fix: config.localEdgeParameters[{n}, {n}]["{k}"] = {v}')
					elif k in Config.ALLOWED_PRGM_PARAMETERS:
						raise KeyError(f'{k} is a program parameter and unsupported in localNodeParameters[{n}]["{k}"]. Fix: config.programParameters[{n}, {n}]["{k}"] = {v}')
					else:
						raise KeyError(f'{k} is an unrecognized parameter and unsupported in localNodeParameters[{n}]["{k}"]. Typo? (Allowable node parameters: {Config.ALLOWED_NODE_PARAMETERS})')
			tqdm_check_update()
		for e, p in self.localEdgeParameters.items():
			n0, n1 = e
			for k, v in p.items():
				if k not in Config.ALLOWED_EDGE_PARAMETERS:
					if k in Config.ALLOWED_NODE_PARAMETERS:
						raise KeyError(f'{k} is a node parameters and unsupported in localEdgeParameters[{n0}, {n1}]["{k}"]. Fix: config.localNodeParameters[{n0}]["{k}"] = {v}')
					elif k in Config.ALLOWED_PRGM_PARAMETERS:
						raise KeyError(f'{k} is a program parameter and unsupported in localEdeParameters[{n0}, {n1}]["{k}"]. Fix: config.programParameters["{k}"] = {v}')
					else:
						raise KeyError(f'{k} is an unrecognized parameter and unsupported in localEdgeParameters["{k}"]. Typo? (Allowable edge parameters: {Config.ALLOWED_EDGE_PARAMETERS})')
			tqdm_check_update()
		for r, p in self.regionNodeParameters.items():
			for k, v in p.items():
				if k not in Config.ALLOWED_NODE_PARAMETERS:
					if k in Config.ALLOWED_EDGE_PARAMETERS:
						raise KeyError(f'{k} is an edge parameters and unsupported in regionNodeParameters[{r}]["{k}"]. Fix: config.regionEdgeParameters[{r}]["{k}"] = {v}')
					elif k in Config.ALLOWED_PRGM_PARAMETERS:
						raise KeyError(f'{k} is a program parameter and unsupported in regionNodeParameters[{r}]["{k}"]. Fix: config.programParameters[{r}]["{k}"] = {v}')
					else:
						raise KeyError(f'{k} is an unrecognized parameter and unsupported in regionNodeParameters[{r}]["{k}"]. Typo? (Allowable node parameters: {Config.ALLOWED_NODE_PARAMETERS})')
			tqdm_check_update()
		for r, p in self.regionEdgeParameters.items():
			for k, v in p.items():
				if k not in Config.ALLOWED_EDGE_PARAMETERS:
					if k in Config.ALLOWED_NODE_PARAMETERS:
						raise KeyError(f'{k} is a node parameters and unsupported in regionEdgeParameters[{r}]["{k}"]. Fix: config.regionNodeParameters[{r}]["{k}"] = {v}')
					elif k in Config.ALLOWED_PRGM_PARAMETERS:
						raise KeyError(f'{k} is a program parameter and unsupported in regionEdgeParameters[{r}]["{k}"]. Fix: config.programParameters[{r}]["{k}"] = {v}')
					else:
						raise KeyError(f'{k} is an unrecognized parameter and unsupported in regionNodeParameters[{r}]["{k}"]. Typo? (Allowable edge parameters: {Config.ALLOWED_EDGE_PARAMETERS})')
			tqdm_check_update()
		for k, v in self.globalParameters.items():
			if k not in Config.ALLOWED_NODE_PARAMETERS | Config.ALLOWED_EDGE_PARAMETERS:
				if k in Config.ALLOWED_PRGM_PARAMETERS:
					raise KeyError(f'{k} is a program parameter and unsupported in globalParameters["{k}"]. Fix: config.prograParameters["{k}"] = {v}')
				else:
					raise KeyError(f'{k} is an unrecognized parameter and unsupported in globalParameters["{k}"]. Typo? (Allowable node/edge parameters: {Config.ALLOWED_NODE_PARAMETERS | Config.ALLOWED_EDGE_PARAMETERS})')
			tqdm_check_update()
		for k, v in self.programParameters.items():
			if k not in Config.ALLOWED_PRGM_PARAMETERS:
				if k in Config.ALLOWED_NODE_PARAMETERS:
					raise KeyError(f'{k} is a node parameter and unsupported in programParameters["{k}"]. Fix: config.globalParameters["{k}"] = {v}')
				elif k in Config.ALLOWED_EDGE_PARAMETERS:
					raise KeyError(f'{k} is an edge parameter and unsupported in programParameters["{k}"]. Fix: config.globalParameters["{k}"] = {v}')
				else:
					raise KeyError(f'{k} is an unrecognized parameter and unsupported in programParameters["{k}"]. Typo? (Allowable program parameters: {Config.ALLOWED_PRGM_PARAMETERS})')
			tqdm_check_update()
		
		# CHECK: Is PRNG algorithm supported?
		if prng not in ["xoshiro256**", "xoshiro256++", "xoshiro256+"]:
			raise ValueError(f"Unsupported psuedo-random number generator algorithm: {prng}. Suggested algorithm model.programParameters[\"prng\"] = \"xoshiro256**\"")
		tqdm_check_update()
		if seed is not None:
			for s in seed:
				if not isinstance(s, int):
					raise ValueError(f"Seed(s) must be type int: {s}, type={type(s)}")
				if s < 0 or s >= 2**64:
					raise ValueError(f"Seed value {s} is out-of-range [0, 2**64)")
				tqdm_check_update()

		# other (dependant) variables
		self.localNodeKeys = Config.innerKeys(self.localNodeParameters)    # set[str]
		self.localEdgeKeys = Config.innerKeys(self.localEdgeParameters)    # set[str]
		self.regionNodeKeys = Config.innerKeys(self.regionNodeParameters)  # set[str]
		self.regionEdgeKeys = Config.innerKeys(self.regionEdgeParameters)  # set[str]
		self.globalKeys = { *self.globalParameters.keys() }                # set[str]
		self.allKeys = self.localNodeKeys | self.localEdgeKeys | self.regionNodeKeys | self.regionEdgeKeys | self.globalKeys
		self.constParameters = self.allKeys - self.variableParameters  # set[str]
		self.immutableNodes = self.calcImmutableNodes()  # list[Node]
		self.regionCombos = self.calcAllRegionCombos()  # list[tuple[Region|None, Region|None]]
		self.nodeIndex = {}  # dict[Node, int]
		self.edgeIndex = {}  # dict[Edge, int]
		tqdm_check_update()

		# CHECK: Do all keys in localNodeParameters reference nodes in self.nodes?
		for node in self.localNodeParameters:
			if node not in self.nodes:
				raise KeyError(f"dict key {node} in localNodeParameters is not a defined node in config.nodes")
			tqdm_check_update()

		# CHECK: Do all keys in localEdgeParameters reference edges in self.edgs?
		for edge in self.localEdgeParameters:
			if type(edge) is not tuple:
				raise KeyError(f"dict key {edge} in localEdgeParameters must be a tuple: type={type(edge)}")
			if len(edge) != 2:
				raise KeyError(f"dict key {edge} in localEdgeParameter must reference exactly 2 nodes: len={len(edge)}")
			if edge not in self.edges:
				raise KeyError(f"dict key {edge} in localEdgeParameters is not a defined edge in config.edges")
			tqdm_check_update()

		# CHECK: Do all keys in regionNodeParameters reference regions in self.regions?
		for region in self.regionNodeParameters:
			if region not in self.regions:
				raise KeyError(f"dit key {region} in regionNodeParameters is not a defined region in config.regions")
			tqdm_check_update()

		# CHECK: Do all edge-regions reference regions that actually exists in self.regions?
		for combo in self.regionEdgeParameters.keys():
			if type(combo) is not tuple:
				raise KeyError(f"dict keys {combo} in regionEdgeParameters must be a tuple: type={type(combo)}")
			if len(combo) != 2:
				raise KeyError(f"dict key {combo} in regionEdgeParameters must reference exactly 2 regions (or None): len={len(combo)}")
			if combo not in self.regionCombos:
				raise KeyError(f"dict key {combo} in regionEdgeParameters is not referencing a defined edge-region. Defined edge-regions are: {self.regionCombos}")
			tqdm_check_update()
		
		# CHECK: dkT, dB, etc. parameters depend on kT, B, etc.
		def param_depends_on(p, *dependancies):
			for node in self.mutableNodes:
				params = self.localNodeParameters.get(node, {})
				if p in params and any(d not in params for d in dependancies):
					raise ValueError(f"{p} defined for node {node}. {dependancies} must then also be defined for this (mutable) node.")
				tqdm_check_update()
			for region in self.regions:
				params = self.regionNodeParameters.get(region, {})
				if p in params and any(d not in params for d in dependancies):
					raise ValueError(f"{p} defined for region {region}. {dependancies} must then also be defined for this region.")
				tqdm_check_update()
			if p in self.globalParameters and any(d not in self.globalParameters for d in dependancies):
				raise ValueError(f"{p} was defined globally. {dependancies} must then also be defined globally.")
			tqdm_check_update()
		param_depends_on("dB", "B")
		param_depends_on("dkT", "kT")

		if tqdm_check is not None:  tqdm_check.close()

		def tqdm_(iterable, desc):
			if progress_bars:
				return tqdm(iterable, desc=desc, **pbar_args)
			return iterable

		exports = []  # [(symbol: str, data: bool), ...]

		src = StrJoiner()
		src += f"; Generated by {__name__} (python) at {datetime.now()}\n"
		# options
		src += "OPTION CASEMAP:NONE\n\n"
		# includes
		if len(self.debug) != 0:
			src += "include dumpreg.inc\n"
		src += "include vec.inc  ; _vdotp, etc.\n"
		src += "include prng.inc  ; splitmix64, xoshiro256ss, etc. \n"
		src += "include ln.inc  ; _vln\n\n"
		
		# ---------------------------------------------------------------------
		src += ".data\n"
		# nodes:
		# allocate memory for "nodes" as an array of structures
		# generate a comment explaining nodes' memory structure
		src += "; struct node {\n"
		src += ";\tdouble spin[4];  // 32 bytes. last element is ignored.\n"
		if "F" in self.allKeys:
			src += ";\tdouble flux[4];  // 32 bytes. last element is ignored.\n"
		if "B" in self.localNodeKeys:
			src += ";\tdouble B[4];     // 32 bytes. last element is ignored.\n"
		if "dB" in self.localNodeKeys:
			src += ";\tdouble dB[4];    // 32 bytes. last element is ignored.\n"
		if "A" in self.localNodeKeys:
			src += ";\tdouble A[4];     // 32 bytes. last element is ignored.\n"
		if any(p in self.localNodeKeys for p in {"S", "F", "kT", "Je0"}):
			src += ";\tdouble S, F, kT, Je0;  // 32 bytes. unused parameters are ignored.\n"
		if "dkT" in self.localNodeKeys:
			src += ";\tdouble _, _, dkT, _;   // 32 bytes. unused parameters are ignored.\n"
		src += "; }\n"
		# symbolic constants related to nodes' memory structure
		offset32 = 0  # tracks current position as we iterate through struct in 32-byte chunks
		self.OFFSETOF_SPIN = 32 * offset32
		src += f"OFFSETOF_SPIN EQU 32*({offset32})\n";  offset32 += 1
		if "F" in self.allKeys:
			self.OFFSETOF_FLUX = 32 * offset32
			src += f"OFFSETOF_FLUX EQU 32*({offset32})\n";  offset32 += 1
		if "B" in self.localNodeKeys:
			self.OFFSETOF_B = 32 * offset32
			src += f"OFFSETOF_B    EQU 32*({offset32})\n";  offset32 += 1
		if "dB" in self.localNodeKeys:
			self.OFFSETOF_dB = 32 * offset32
			src += f"OFFSETOF_dB   EQU 32*({offset32})\n";  offset32 += 1
		if "A" in self.localNodeKeys:
			self.OFFSETOF_A = 32 * offset32
			src += f"OFFSETOF_A    EQU 32*({offset32})\n";  offset32 += 1
		if any(p in self.localNodeKeys for p in {"S", "F", "kT", "Je0"}):
			if "S" in self.localNodeKeys:    src += f"OFFSETOF_S    EQU 32*({offset32}) + 8*(0)\n";  self.OFFSETOF_S   = 32 * offset32 + 8*0
			if "F" in self.localNodeKeys:    src += f"OFFSETOF_F    EQU 32*({offset32}) + 8*(1)\n";  self.OFFSETOF_F   = 32 * offset32 + 8*1
			if "kT" in self.localNodeKeys:   src += f"OFFSETOF_kT   EQU 32*({offset32}) + 8*(2)\n";  self.OFFSETOF_kT  = 32 * offset32 + 8*2
			if "Je0" in self.localNodeKeys:  src += f"OFFSETOF_Je0  EQU 32*({offset32}) + 8*(3)\n";  self.OFFSETOF_Je0 = 32 * offset32 + 8*3
			offset32 += 1
		if "dkT" in self.localNodeKeys:
			if True:                         src += f"OFFSETOF_dkT  EQU 32*({offset32}) + 8*(2)\n";  self.OFFSETOF_dkT = 32 * offset32 + 8*2
			offset32 += 1
		self.SIZEOF_NODE = 32 * offset32
		src += f"SIZEOF_NODE   EQU 32*({offset32})\n"
		self.MUTABLE_NODE_COUNT = len(self.mutableNodes)
		src += f"MUTABLE_NODE_COUNT   EQU {len(self.mutableNodes)}\n"
		self.IMMUTABLE_NODE_COUNT = len(self.immutableNodes)
		src += f"IMMUTABLE_NODE_COUNT EQU {len(self.immutableNodes)}\n"
		self.NODE_COUNT = len(self.nodes)
		src += f"NODE_COUNT           EQU {len(self.nodes)}\n\n"
		# define memeory for nodes
		src += "NODES SEGMENT ALIGN(32)  ; AVX-256 (i.e. 32-byte) alignment\n"
		src += "nodes\t"
		for i, node in tqdm_(enumerate([*self.mutableNodes, *self.immutableNodes]), "[Compiling] Writing ASM .data nodes"):
			self.nodeIndex[node] = i  # store map: node -> array index
			if i != 0:  src += "\t\t"  # ASM formating: first struct must be on same line as symbol (i.e. "nodes")
			params = self.localNodeParameters.get(node, {})  # dict
			src += "dq 0.0, 1.0, 0.0, 0.0"  # init spin <0, 1, 0>
			if "F" in self.allKeys:
				src += ", \t0.0, 0.0, 0.0, 0.0"  # init flux <0, 0, 0>
			if "B" in self.localNodeKeys:
				Bx, By, Bz = asm_floats(params.get("B", (0.0, 0.0, 0.0)))  # unpack generator
				src += f", \t{Bx}, {By}, {Bz}, 0.0"
			if "dB" in self.localNodeKeys:
				dBx, dBy, dBz = asm_floats(params.get("dB", (0.0, 0.0, 0.0)))  # unpack generator
				src += f", \t{dBx}, {dBy}, {dBz}, 0.0"
			if "A" in self.localNodeKeys:
				Ax, Ay, Az = asm_floats(params.get("A", (0.0, 0.0, 0.0)))  # unpack generator
				src += f", \t{Ax}, {Ay}, {Az}, 0.0"
			if any(p in self.localNodeKeys for p in {"S", "F", "kT", "Je0"}):
				S = asm_float(params.get("S", 0.0))
				F = asm_float(params.get("F", 0.0))
				kT = asm_float(params.get("kT", 0.0))
				Je0 = asm_float(params.get("Je0", 0.0))
				src += f", \t{S}, {F}, {kT}, {Je0}"
			if "dkT" in self.localNodeKeys:
				dkT = asm_float(params.get("kT", 0.0))
				src += f", \t0.0, 0.0, {dkT}, 0.0"
			const = "const " if i >= len(self.mutableNodes) else ""
			regions = self.getRegions(node)
			regions = f" in {regions}" if len(regions) != 0 else ""
			src += f"  ; {const}nodes[{i}]: id=\"{self.nodeId(node)}\"{regions}\n"
		src += "NODES ENDS\n\n"
		exports.append(("nodes", True))

		# regions:
		# generate a comment explaining (node) regions' memory structure
		src += "; struct region {\n"
		if "B" in self.regionNodeKeys:
			src += ";\tdouble B[4];     // 32 bytes. last element is ignored.\n"
		if "dB" in self.regionNodeKeys:
			src += ";\tdouble dB[4];    // 32 bytes. last element is ignored.\n"
		if "A" in self.regionNodeKeys:
			src += ";\tdouble A[4];     // 32 bytes. last element is ignored.\n"
		if any(p in self.regionNodeKeys for p in {"S", "F", "kT", "Je0"}):
			src += ";\tdouble S, F, kT, Je0;  // 32 bytes. unused parameters are ignored.\n"
		if "dkT" in self.regionNodeKeys:
			src += ";\tdouble _, _, dkT, _;   // 32 bytes. unsued parameters are ignored.\n"
		src += "; }\n"
		# symbolic constants related to regions' memory structure
		offset32 = 0  # tracks current position as we iterate through struct in 32-byte chunks
		if "B" in self.regionNodeKeys:
			self.OFFSETOF_REGION_B = 32 * offset32
			src += f"OFFSETOF_REGION_B   EQU 32*({offset32})\n";  offset32 += 1
		if "dB" in self.regionNodeKeys:
			self.OFFSETOF_REGION_dB = 32 * offset32
			src += f"OFFSETOF_REGION_dB  EQU 32*({offset32})\n";  offset32 += 1
		if "A" in self.regionNodeKeys:
			self.OFFSETOF_REGION_A = 32 * offset32
			src += f"OFFSETOF_REGION_A   EQU 32*({offset32})\n";  offset32 += 1
		if any(p in self.regionNodeKeys for p in {"S", "F", "kT", "Je0"}):
			if "S"   in self.regionNodeKeys:  src += f"OFFSETOF_REGION_S   EQU 32*({offset32}) + 8*(0)\n";  self.OFFSETOF_REGION_S   = 32 * offset32 + 8*0
			if "F"   in self.regionNodeKeys:  src += f"OFFSETOF_REGION_F   EQU 32*({offset32}) + 8*(1)\n";  self.OFFSETOF_REGION_F   = 32 * offset32 + 8*1
			if "kT"  in self.regionNodeKeys:  src += f"OFFSETOF_REGION_kT  EQU 32*({offset32}) + 8*(2)\n";  self.OFFSETOF_REGION_kT  = 32 * offset32 + 8*2
			if "Je0" in self.regionNodeKeys:  src += f"OFFSETOF_REGION_Je0 EQU 32*({offset32}) + 8*(3)\n";  self.OFFSETOF_REGION_Je0 = 32 * offset32 + 8*3
			offset32 += 1
		if "dkT" in self.regionNodeKeys:
			if True:                          src += f"OFFSETOF_REGION_dkT EQU 32*({offset32}) + 8*(2)\n";  self.OFFSETOF_REGION_dkT = 32 * offset32 + 8*2
			offset32 += 1
		self.SIZEOF_REGION = 32 * offset32
		src += f"SIZEOF_REGION EQU 32*({offset32})\n"
		self.REGION_COUNT = len(self.regionNodeParameters.keys())
		src += f"REGION_COUNT  EQU {len(self.regionNodeParameters.keys())}\n\n"
		# define memeory for regions
		src += "REGIONS SEGMENT ALIGN(32)  ; AVX-256 (i.e. 32-byte) alignment\n"
		if self.REGION_COUNT != 0:
			src += "  regions LABEL qword\n"
			exports.append(("regions", True))
		else:
			src += "; regions  ; (0 bytes) none defined\n"
		for region in tqdm_(self.regions, "[Compiling] Writing ASM .data regions"):
			rid = self.regionId(region)
			if region not in self.regionNodeParameters:
				src += f"; {rid}\n"
				continue  # skip defining this region. it has no special parameters.
			params = self.regionNodeParameters[region]  # dict
			src += f"  {rid}\tdq "
			if "B" in self.regionNodeKeys:
				Bx, By, Bz = asm_floats(params.get("B", (0.0, 0.0, 0.0)))  # unpack generator
				src += f"{Bx}, {By}, {Bz}, 0.0,\t"
			if "dB" in self.regionNodeKeys:
				dBx, dBy, dBz = asm_floats(params.get("dB", (0.0, 0.0, 0.0)))  # unpack generator
				src += f"{dBx}, {dBy}, {dBz}, 0.0,\t"
			if "A" in self.regionNodeKeys:
				Ax, Ay, Az = asm_floats(params.get("A", (0.0, 0.0, 0.0)))  # unpack generator
				src += f"{Ax}, {Ay}, {Az}, 0.0,\t"
			if any(p in self.regionNodeKeys for p in {"S", "F", "kT", "Je0"}):
				S   = asm_float(params.get("S",   0.0))
				F   = asm_float(params.get("F",   0.0))
				kT  = asm_float(params.get("kT",  0.0))
				Je0 = asm_float(params.get("Je0", 0.0))
				src += f"{S}, {F}, {kT}, {Je0},\t"
			if "dkT" in self.regionNodeKeys:
				dkT = asm_float(params.get("dkT", 0.0))
				src += f"0.0, 0.0, {dkT}, 0.0,\t"
			src.pieces[-1] = src.pieces[-1][0:-2]  # remove last 2-char ",\t" delimeter
			src += "\n"
			exports.append((rid, True))
		src += "REGIONS ENDS\n\n"
		
		# global parameters (node only):
		src += "GLOBAL_NODE SEGMENT ALIGN(32)\n"
		if any(p in self.globalKeys for p in ["B", "dB", "A", "S", "F", "kT", "Je0", "dkT"]):
			src += "global_node LABEL qword\n"
			exports.append(("global_node", True))
		else:
			src += "; global_node  ; (0 bytes) none defined"
		params = self.globalParameters
		if "B" in self.globalKeys:
			Bx, By, Bz = asm_floats(params["B"])  # unpack generator
			src += f"B   dq {Bx}, {By}, {Bz}, 0.0\n"
			exports.append(("B", True))
		if "dB" in self.globalKeys:
			dBx, dBy, dBz = asm_floats(params["dB"])  # unpack generator
			src += f"dB_ dq {dBx}, {dBy}, {dBz}, 0.0\n"  # NOTE: dB is ASM directive (define byte)
			exports.append(("dB_", True))
		if "A" in self.globalKeys:
			Ax, Ay, Az = asm_floats(params["A"])  # unpack generator
			src += f"A   dq {Ax}, {Ay}, {Az}, 0.0\n"
			exports.append(("A", True))
		if any(p in self.globalKeys for p in ["S", "F", "kT", "Je0"]):
			S   = asm_float(params.get("S",   0.0))
			F   = asm_float(params.get("F",   0.0))
			kT  = asm_float(params.get("kT",  0.0))
			Je0 = asm_float(params.get("Je0", 0.0))
			src += f"S   dq {S}\n"
			src += f"F   dq {F}\n"
			src += f"kT  dq {kT}\n"
			src += f"Je0 dq {Je0}\n"
			exports.append(("S", True))
			exports.append(("F", True))
			exports.append(("kT", True))
			exports.append(("Je0", True))
		if "dkT" in self.globalKeys:
			dkT = asm_float(params.get("dkT", 0.0))
			src +=  "    dq 0.0\n"
			src +=  "    dq 0.0\n"
			src += f"dkT dq {dkT}\n"
			src +=  "    dq 0.0\n"
			exports.append(("dkT", True))
		src += "GLOBAL_NODE ENDS\n\n"

		# edges:
		# generate a comment explaining edges' memory structure
		src += "; struct edge {\n"
		if any(p in self.localEdgeKeys for p in ["J", "Je1", "Jee", "b"]):
			src += ";\tdouble J, Je1, Jee, b;  // 32 bytes. unused fields ignored.\n"
		if "D" in self.localEdgeKeys:
			src += ";\tdouble D[4];            // 32 bytes. last element ignored.\n"
		src += "; }\n"
		# symbolic constants related to regions' memory structure
		offset32 = 0  # tracks current position as we iterate through struct in 32-byte chunks
		if any(p in self.localEdgeKeys for p in ["J", "Je1", "Jee", "b"]):
			if "J"   in self.localEdgeKeys:  src += f"OFFSETOF_J   EQU 32*({offset32}) + 8*(0)\n";  self.OFFSETOF_J   = 32 * offset32 + 8*0
			if "Je1" in self.localEdgeKeys:  src += f"OFFSETOF_Je1 EQU 32*({offset32}) + 8*(1)\n";  self.OFFSETOF_Je1 = 32 * offset32 + 8*1
			if "Jee" in self.localEdgeKeys:  src += f"OFFSETOF_Jee EQU 32*({offset32}) + 8*(2)\n";  self.OFFSETOF_Jee = 32 * offset32 + 8*2
			if "b"   in self.localEdgeKeys:  src += f"OFFSETOF_Je1 EQU 32*({offset32}) + 8*(3)\n";  self.OFFSETOF_b   = 32 * offset32 + 8*3
			offset32 += 1
		if "D" in self.localEdgeKeys:
			self.OFFSETOF_D = 32 * offset32
			src += f"OFFSETOF_D  EQU 32*({offset32})";  offset32 += 1
		self.SIZEOF_EDGE = 32 * offset32
		src += f"SIZEOF_EDGE  EQU 32*({offset32})\n"
		self.EDGE_COUNT = len(self.edges)
		src += f"EDGE_COUNT EQU {len(self.edges)}\n\n"
		# define memeory for edges
		src += "EDGES SEGMENT ALIGN(32)\n"
		if len(self.localEdgeKeys) == 0:
			src += "; edges  ; (0 bytes) array of empty edge structs\n"
		else:
			src += "edges\t"
			for i, edge in tqdm_(enumerate(self.edges), "[Compiling] Writing ASM .data edges"):
				self.edgeIndex[edge] = i
				if i != 0:  src += "\t\t"  # ASM formating: first struct must be on same line as symbol (i.e. "edges")
				src += "dq "
				params = self.localEdgeParameters.get(edge, {})
				if any(p in self.localEdgeKeys for p in ["J", "Je1", "Jee", "b"]):
					J   = asm_float(params.get("J",   0.0))
					Je1 = asm_float(params.get("Je1", 0.0))
					Jee = asm_float(params.get("Jee", 0.0))
					b   = asm_float(params.get("b",   0.0))
					src += f"{J}, {Je1}, {Jee}, {b},\t"
				if "D" in self.localEdgeKeys:
					Dx, Dy, Dz = asm_floats(params.get("D", (0.0, 0.0, 0.0)))
					src += f"{Dx}, {Dy}, {Dz}, 0.0,\t"
				src.pieces[-1] = src.pieces[-1][0:-2]  # remove last 2-char ",\t" delimeter
				regions = self.getRegionCombos(edge)
				regions = f" in {regions}" if len(regions) != 0 else ""
				src += f"  ; edges[{i}]: {self.nodeId(edge[0])} -> {self.nodeId(edge[1])}{regions}\n"
			exports.append(("edges", True))
		src += "EDGES ENDS\n\n"

		# edge_regions:
		# generate a comment explaining edge_regions' memory structure
		src += "; struct edge_region {\n"
		if any(p in self.regionEdgeKeys for p in ["J", "Je1", "Jee", "b"]):
			src += ";\tdouble J, Je1, Jee, b;  // 32 bytes. unused fields are ignored.\n"
		if "D" in self.regionEdgeKeys:
			src += ";\tdouble D[4];            // 32 bytes. last element ignored.\n"
		src += "; }\n"
		# symbolic constants related to edge_regions' memory structure
		offset32 = 0  # tracks current position as we iterate through struct in 32-byte chunks
		if any(p in self.regionEdgeKeys for p in ["J", "Je1", "Jee", "b"]):
			if "J"   in self.regionEdgeKeys:  src += f"OFFSETOF_REGION_J   EQU 32*({offset32}) + 8*(0)\n";  self.OFFSETOF_REGION_J   = 32 * offset32 + 8*0
			if "Je1" in self.regionEdgeKeys:  src += f"OFFSETOF_REGION_Je1 EQU 32*({offset32}) + 8*(1)\n";  self.OFFSETOF_REGION_Je1 = 32 * offset32 + 8*1
			if "Jee" in self.regionEdgeKeys:  src += f"OFFSETOF_REGION_Jee EQU 32*({offset32}) + 8*(2)\n";  self.OFFSETOF_REGION_Jee = 32 * offset32 + 8*2
			if "b"   in self.regionEdgeKeys:  src += f"OFFSETOF_REGION_b   EQU 32*({offset32}) + 8*(3)\n";  self.OFFSETOF_REGION_b   = 32 * offset32 + 8*3
			offset32 += 1
		if "D" in self.regionEdgeKeys:
			self.OFFSETOF_REGION_D = 32 * offset32
			src += f"OFFSETOF_REGION_D   EQU 32*({offset32})\n";  offset32 += 1
		self.SIZEOF_EDGE_REGION = 32 * offset32
		src += f"SIZEOF_EDGE_REGION  EQU 32*({offset32})\n"
		self.EDGE_REGION_COUNT = sum(1 for combo in self.regionCombos if combo in self.regionEdgeParameters)
		src += f"EDGE_REGION_COUNT EQU {self.EDGE_REGION_COUNT}\n\n"
		# define memeory for edge_regions
		src += "EDGE_REGIONS SEGMENT ALIGN(32)\n"
		if self.EDGE_REGION_COUNT != 0:
			src += "  edge_regions LABEL qword\n"
			exports.append(("edge_regions", True))
		else:
			src += "; edge_regions  ; (0 bytes) none defined\n"
		for r0, r1 in tqdm_(self.regionCombos, "[Compiling] Writing ASM .data edge_regions"):
			rid = f"{self.regionId(r0)}_{self.regionId(r1)}"
			if (r0, r1) not in self.regionEdgeParameters:
				src += f"; {rid}\n"
				continue  # skip defining this edge_region. it has no special parameters.
			params = self.regionEdgeParameters[(r0, r1)]
			src += f"  {rid}\tdq "
			if any(p in self.regionEdgeKeys for p in ["J", "Je1", "Jee", "b"]):
				J   = asm_float(params.get("J",   0.0))
				Je1 = asm_float(params.get("Je1", 0.0))
				Jee = asm_float(params.get("Jee", 0.0))
				b   = asm_float(params.get("b",   0.0))
				src += f"{J}, {Je1}, {Jee}, {b},\t"
			if "D" in self.regionEdgeKeys:
				Dx, Dy, Dz = asm_floats(params.get("D", (0.0, 0.0, 0.0)))
				src += f"{Dx}, {Dy}, {Dz}, 0.0,\t"
			src.pieces[-1] = src.pieces[-1][0:-2]  # remove last 2-char ",\t" delimeter
			src += "\n"
			exports.append((rid, True))
		src += "EDGE_REGIONS ENDS\n\n"

		# global parameters (edge only):
		src += "GLOBAL_EDGE SEGMENT ALIGN(32)\n"
		if any(p in self.globalKeys for p in ["J", "Je1", "Jee", "b", "D"]):
			src += "global_edge LABEL qword\n"
			exports.append(("global_edge", True))
		else:
			src += "; global_edge  ; (0 bytes) none defined\n"
		params = self.globalParameters
		if any(p in self.globalKeys for p in ["J", "Je1", "Jee", "b"]):
			J   = asm_float(params.get("J",   0.0))
			Je1 = asm_float(params.get("Je1", 0.0))
			Jee = asm_float(params.get("Jee", 0.0))
			b   = asm_float(params.get("b",   0.0))
			src += f"J   dq {J}\n"
			src += f"Je1 dq {Je1}\n"
			src += f"Jee dq {Jee}\n"
			src += f"b   dq {b}\n"
			exports.append(("J", True))
			exports.append(("Je1", True))
			exports.append(("Jee", True))
			exports.append(("b", True))
		if "D" in self.globalKeys:
			Dx, Dy, Dz = asm_floats(params["D"])
			src += f"D   dq {Dx}, {Dy}, {Dz}, 0.0\n"
			exports.append(("D", True))
		src += "GLOBAL_EDGE ENDS\n\n"

		# parallel arrays:
		def node_ref_array(src, exports, ks: list, vs=0.0, name=None, align: int=None) -> None:
			""" Generate .data array of pointers to some node field, k, for each mutable node. """
			if name is None:
				name = f"{''.join(ks)}ref"
			src += f"; array of {ks} pointers (double *) parallel to (mutable) nodes\n"
			if align is not None:
				src += f"{name.upper()} SEGMENT ALIGN({align})\n"
			src += f"{name}\t"
			if len(self.mutableNodes) == 0:
				src += "; 0 byte array. no mutable nodes.\n"
			first_line = True
			for node in tqdm_(self.mutableNodes, f"[Compiling] Writing ASM .data {name}"):
				idx = self.nodeIndex[node]
				for k, v in zip(ks, vs):
					if first_line:
						first_line = False
					else:
						src += "\t\t"  # ASM formating: first struct must be on same line as symbol (i.e. "dU")
					if k in self.localNodeParameters.get(node, {}):
						src += f"dq nodes + SIZEOF_NODE*{idx} + OFFSETOF_{k}  ; nodes[{idx}] -> &nodes[{idx}].{k} (local)\n"
					else:
						_, region = self.getUnambiguousRegionNodeParameter(node, k)  # we don't need value, only region
						if region is not None:
							rid = self.regionId(region)
							src += f"dq {rid} + OFFSETOF_REGION_{k}  ; nodes[{idx}] -> &{rid}.{k} (region)\n"
						elif k in self.globalKeys:
							src += f"dq {k}  ; nodes[{idx}] -> &{k} (global)\n"
						else:
							raise ValueError(f"For mutable node {self.nodeId(node)}, {k} is not defined at any level. Potential fix: model.globalParameters[\"{k}\"] = {v}")
			if align is not None:
				src += f"{name.upper()} ENDS\n"
			src += "\n"
			exports.append((name, True))
			return str(src)

		# S,F parallel array
		if "F" in self.allKeys:
			node_ref_array(src, exports, ["S", "F"], [1.0, 0.0], align=16)
		else:
			node_ref_array(src, exports, ["S"], [1.0])

		# deltaU array (function pointers):
		src += "; array of function pointers parallel to (mutable) nodes\n"
		src += "deltaU\t"
		if len(self.mutableNodes) == 0:
			src += "; 0 byte empty array. no multable nodes.\n"
		for i, node in tqdm_(enumerate(self.mutableNodes), "[Compiling] Writing ASM .data deltaU (ptr)"):
			if i != 0:  # loop index, not node index.
				src += "\t\t"  # ASM formating: first struct must be on same line as symbol (i.e. "dU")
			src += f"dq deltaU_{self.nodeId(node)}  ; nodes[{self.nodeIndex[node]}]\n"
		src += "\n"
		exports.append(("deltaU", True))

		# kT parallel array
		node_ref_array(src, exports, ["kT"], [0.1])

		# misc. constants
		# src += "; misc. constants\n"
		# src += "ONE dq 1.0\n\n"

		# PRNG state
		if prng.startswith("xoshiro256"):  # TODO: support other PRNGs
			if seed is None or len(seed) == 0:
				src += ".data?\n"
				src += "PRNG SEGMENT ALIGN(32)\n"
				src += f"; Vectorized {prng}\n"
				src += "prng_state dq 4 dup (?, ?, ?, ?)  ; initialized at runtime\n"
				src += "PRNG ENDS\n\n"
			else:
				src += ".data\n"
				src += "PRNG SEGMENT ALIGN(32)\n"
				# use given seed, plus SplitMix64 if len < 16
				prng_state = Runtime._generateXoshiro256State(seed)
				src += "prng_state dq\t"
				for i, row in enumerate(prng_state):
					if i != 0:
						src += "\t\t\t\t"
					for j, value in enumerate(row):
						src += f"0{value:016x}h"
						if   j != 3:  src += ",\t"
						elif i != 3:  src += ","
					src += "\n"
				src += "PRNG ENDS\n\n"
			exports.append(("prng_state", True))

		# ---------------------------------------------------------------------
		src += ".code\n"
		# deltaU PROCs:
		# documentation for deltaU_{nodeId} PROCs
		src +=  "; @return ymm0: -\\Delta U (Negated for Boltzmann distribution.)\n"
		src +=  "; @param  ymm1: s'_i\n"
		flux_note: str = " (unused)" if "F" not in self.allKeys else ""
		src += f"; @param  ymm2: f'_i{flux_note}\n"
		src +=  ";         ymm3: temp/scratch reg.\n"
		src +=  ";         ymm4: s_i, m_i, then (unused)\n"
		src +=  ";         ymm5: f_i, m'_i, then (unused)\n"
		src +=  ";         ymm6: (unused), \\Delta s_i, then \\Delta m_i\n"
		src +=  ";         ymm7: (unused), \\Delta f_i, then (unused)\n"
		src +=  ";         ymm8: s_j, f_j, or m_j\n"
		src +=  ";         ymm9: temp/scratch reg.\n"
		# code for deltaU_{nodeId} PROCs
		if len(self.mutableNodes) == 0:
			src += "; deltaU_{nodeId} PROCs missing. No mutable nodes!\n\n"
		else:
			for node in tqdm_(self.mutableNodes, "[Compiling] Writing ASM .code deltaU (PROC)"):
				nid = self.nodeId(node)
				proc_id = f"deltaU_{nid}"
				index = self.nodeIndex[node]
				hasFlux: bool = self.hasFlux(node)
				flux_mode: bool = hasFlux and (
					self.hasJe0(node) or  # explicitly use f
					self.hasJe1(node) or
					self.hasJee(node) or
					self.hasA(node) or  # use m = s + f
					self.hasB(node) or
					self.hasb(node) or
					self.hasD(node)
				)

				# registers:
				resx, resy = "xmm0", "ymm0"   # result (return: -ΔU = -ΔU_Je0 - ΔU_A - ΔU_J - ΔU_Je1 - ΔU_Jee - ΔU_b - ΔU_B - ΔU_D)
				s1i = "ymm1"                  # s'_i (param: new spin)
				f1i = "ymm2"                  # f'_i (param: new flux)
				prmx, prmy = "xmm3", "ymm3"   # TODO: rename. Now just used as temp. scalar parameter (Je0, J, Je1, Jee, b), or vector parameter (A, B, D)
				smix, smi = "xmm4", "ymm4"    # s_i, m_i, then (unused)
				fm1 = "ymm5"                  # f_i, m'_i, then (unused)
				dsm = "ymm6"                  # (unused), Δs_i, then Δm_i
				dfix, dfi = "xmm7", "ymm7"    # (unused), Δf_i, then (unused)
				sfmjx, sfmj = "xmm8", "ymm8"  # s_j, f_j, or m_j
				tmpx, tmpy = "xmm9", "ymm9"   # temp/scratch reg. (scalar/vector)

				# state
				out_init: bool = False  # track if output register has been initialized yet
				
				src += f"{proc_id} PROC  ; node[{index}]\n"
				# No preable: no local vars. so no stack space needed.
				# comments about what is being skipped:
				s = ""
				if "Je0" not in self.allKeys:  s += "\t; skipping -deltaU_Je0\n"
				if "A"   not in self.allKeys:  s += "\t; skipping -deltaU_A\n"
				if "J"   not in self.allKeys:  s += "\t; skipping -deltaU_J\n"
				if "Je1" not in self.allKeys:  s += "\t; skipping -deltaU_Je1\n"
				if "Jee" not in self.allKeys:  s += "\t; skipping -deltaU_Jee\n"
				if "b"   not in self.allKeys:  s += "\t; skipping -deltaU_b\n"
				if "B"   not in self.allKeys:  s += "\t; skipping -deltaU_B\n"
				if "D"   not in self.allKeys:  s += "\t; skipping -deltaU_D\n"
				src += s
				if len(s) != 0:  src += "\n"
				# Phase 1: load (s_i, f_i) -> -ΔU_(Je0):
				phase1: bool = False  # does phase 1 contain any code?
				src1 = StrJoiner()    # buffer phase 1 src to emit after load
				# try to compute -ΔU_Je0 = Je0 (s'⋅f' - s⋅f):
				if "Je0" in self.allKeys:
					src1 += "\t; -deltaU_Je0 calculation\n"
					# where is Je0 defined?
					load_insn, load_cmnt = None, None
					if "Je0" in self.localNodeParameters.get(node, {}):
						load_insn, load_cmnt = f"qword ptr [nodes + ({index})*SIZEOF_NODE + OFFSETOF_Je0]", f"load Je0_{nid} (local)"
					else:
						_, region = self.getUnambiguousRegionNodeParameter(node, "Je0")  # we don't need value, only region
						if region is not None:
							rid = self.regionId(region)
							load_insn, load_cmnt = f"qword ptr [{rid} + OFFSETOF_REGION_Je0]", f"load Je0_{rid} (region)"
						elif "Je0" in self.globalKeys:
							load_insn, load_cmnt = f"qword ptr Je0", f"load Je0 (global)"
					# TODO: add optimization_remove_scalar
					# TODO: add optimization_neg_scalar
					if load_insn is None:
						src1 += "\t; skip. For this node, Je0 is not defined at any level (local, region, nor global).\n\n"
					elif not hasFlux:
						raise KeyError(f"For node {nid}, Je0 is defined, but F is not. Potential fix: model.globalParameters[F] = 0.0")
					else:
						phase1 = True
						# compute s_i'·f_i' - s_i·f_i (difference between new and current dot products for local spin·flux)
						src1 += f"\t_vdotp {tmpx}, {tmpy}, {s1i}, {f1i}, {prmx}      ; ({s1i}, {f1i}) = (s'f')\n"
						src1 += f"\t_vndotadd {tmpx}, {tmpy}, {smi}, {fm1}, {prmx}   ; ({smi}, {fm1}) = (s'f' - sf)\n"
						if not out_init:
							src1 += f"\tvmulsd {resx}, {tmpx}, {load_insn}  ; {load_cmnt}\n\n"
							out_init = True
						else:
							src1 += f"\tvfmadd231sd {resx}, {tmpx}, {load_insn}  ; {load_cmnt}\n\n"
				# Phase 2: compute (m_i, m'_i, Δs_i, Δf_i) -> -ΔU_(A, J, Je1, Jee, b):
				phase2: bool = False  # does phase 2 contain any code?
				src2 = StrJoiner()    # buffer phase 2 src to emit after load
				m1i = fm1 if flux_mode else s1i
				# compute -ΔU_A: A ⋅ (m'_i^{⊙2} - m_i^{⊙2})
				if "A" in self.allKeys:
					src2 += "\t; -deltaU_A calculation\n"
					# where is A defined?
					load_insn, load_cmnt = None, None
					if "A" in self.localNodeParameters.get(node, {}):
						load_insn = f"ymmword ptr [nodes + ({index})*SIZEOF_NODE + OFFSETOF_A]", f"load A_{nid} (local)"
					else:
						_, region = self.getUnambiguousRegionNodeParameter(node, "A")  # don't need value, only region
						if region is not None:
							rid = self.regionId(region)
							load_insn, load_cmnt = f"ymmword ptr [{rid} + OFFSETOF_REGION_A]", f"load A_{rid} (region)"
						elif "A" in self.globalKeys:
							load_insn, load_cmnt = f"ymmword ptr A", f"load A (global)"
					if load_insn is None:
						src2 += f"\t; skip. For this node, A is not defined at any level (local, region, nor global).\n\n"
					else:
						phase2 = True
						src2 += f"\tvmulpd {tmpy}, {m1i}, {m1i}  ; m' Hadamard squared: m'2\n"
						src2 += f"\tvfnmadd231pd {tmpy}, {smi}, {smi}  ; {tmpy} -= {smi} * {smi} -> m'2 - m2\n"
						if not out_init:
							src2 += f"\t_vdotp {resx}, {resy}, {tmpy}, {load_insn}, {sfmjx}  ; {load_cmnt}\n\n"  # {sfmj} is unused for local parameters 
							out_init = True
						else:
							src2 += f"\t_vdotadd {resx}, {resy}, {tmpy}, {load_insn}, {sfmjx}  ; {load_cmnt}\n\n"  # {sfmj} is unused for local parameters
				# compute -ΔU_J = Σ_j{J Δs_i·s_j}:
				if "J" in self.allKeys:
					src2 += "\t; -deltaU_J calculation\n"
					# figure out where all neighboring edges load J from, and group the common load instructions
					load_groups: dict[tuple[str, str], list] = defaultdict(list)  # dict: (str load_insn, str load_cmnt) -> list[Edge]
					for edge in self.connections(node):
						if "J" in self.localEdgeParameters.get(edge, {}):
							eindex = self.edgeIndex[edge]
							nid0 = self.nodeId(edge[0])
							nid1 = self.nodeId(edge[1])
							load_insn, load_cmnt = f"qword ptr [edges + ({eindex})*SIZEOF_EDGE + OFFSETOF_J]", f"load J_{nid0}_{nid1}"
						else:
							_, combo = self.getUnambiguousRegionEdgeParameter(edge, "J")  # don't need value, only region
							if combo is not None:
								rid0, rid1 = self.regionId(combo[0]), self.regionId(combo[1])
								load_insn, load_cmnt = f"qword ptr [{rid0}_{rid1} + OFFSETOF_REGION_J]", f"load J_{rid0}_{rid1} (region)"
							elif "J" in self.globalKeys:
								load_insn, load_cmnt = f"qword ptr J", f"load J (global)"
							else:
								load_insn, load_cmnt = None, None
						load_groups[(load_insn, load_cmnt)].append(edge)
					for i, load_group in enumerate(load_groups.items(), 1):
						load_insn, edges = load_group
						load_insn, load_cmnt = load_insn
						optimization_remove_scalar = False  # TODO: implement optimization. if scalar is const and exactly 1.0
						optimization_neg_scalar = False     # TODO: implement optimization. if scalar is const and exactly -1.0
						src2 += f"\t; [load group {i}]\n"
						tmp_init = False  # tmpx is used as an intermidate for this load group
						for edge in edges:
							# Note: edge in self.edgeIndex may be false if ASM edge array is empty or missing local variables for this edge. This is fine.
							edgelbl = f"edges[{self.edgeIndex[edge]}]" if edge in self.edgeIndex else "edge"
							if load_insn is None:
								src2 += f"\t; skip. For {edgelbl}, J is not defined at any level (local, region, nor global).\n"
							else:
								phase2 = True
								nid0 = self.nodeId(edge[0])
								nid1 = self.nodeId(edge[1])
								neighbor, _ = Config.neighbor(node, edge)  # just need neighbor. communative operation: doesn't care about direction.
								nindex = self.nodeIndex[neighbor]
								nnid = self.nodeId(neighbor)  # neighbor's node id
								src2 += f"\t; {edgelbl}: {nid0} -> {nid1}\n"
								sj_insn, sj_cmnt = f"ymmword ptr [nodes + ({nindex})*SIZEOF_NODE + OFFSETOF_SPIN]", f"load s_{nnid} (neighbor)"
								if optimization_remove_scalar:
									if not out_init:
										src2 += f"\t_vdotp {resx}, {resy}, {dsm}, {sj_insn}, {prmx}  ; optimization (J*=1), {sj_cmnt}\n"
										out_init = True
									else:
										src2 += f"\t_vdotadd {resx}, {resy}, {dsm}, {sj_insn}, {prmx}  ; optimization (J*=1), {sj_cmnt}\n"
								elif optimization_neg_scalar:
									if not out_init:
										src2 += f"\t_vput0 {resx}\n"
										out_init = True
									src2 += f"\t_vndotadds {resx}, {resy}, {dsm}, {sj_insn}, {prmx}  ; optimization (J*=-1), {sj_cmnt}\n"
								else:
									if not tmp_init:
										src2 += f"\t_vdotp {tmpx}, {tmpy}, {dsm}, {sj_insn}, {prmx}  ; {sj_cmnt}\n"
										tmp_init = True
									else:
										src2 += f"\t_vdotadd {tmpx}, {tmpy}, {dsm}, {sj_insn}, {prmx}  ; {sj_cmnt}\n"
						if optimization_remove_scalar or optimization_neg_scalar:
							src2 += "\t; optimization (J*=1,-1): skip load\n"
						elif load_insn is None:
							src2 += "\t; skip parameter loading for the null load group\n"
						else:
							assert tmp_init  # Since each load group must have at least one edge
							if not out_init:
								src2 += f"\tvmulsd {resx}, {tmpx}, {load_insn}  ; {load_cmnt}\n"
								out_init = True
							else:
								src2 += f"\tvfmadd231sd {resx}, {tmpx}, {load_insn}  ; {load_cmnt}\n"
					src2 += "\n"
				# compute -ΔU_Je1 = Σ_j{Je1 (Δs_i·f_j + Δf_i·s_j)}:
				if "Je1" in self.allKeys:
					src2 += "\t; -deltaU_Je1 calculation\n"
					# figure out where all neighboring edges load Je1 from, and group the common load instructions
					load_groups: dict[tuple[str, str], list] = defaultdict(list)  # dict: (str load_insn, str load_cmnt) -> list[Edge]
					for edge in self.connections(node):
						if "Je1" in self.localEdgeParameters.get(edge, {}):
							eindex = self.edgeIndex[edge]
							nid0 = self.nodeId(edge[0])
							nid1 = self.nodeId(edge[1])
							load_insn, load_cmnt = f"qword ptr [edges + ({eindex})*SIZEOF_EDGE + OFFSETOF_Je1]", f"load Je1_{nid0}_{nid1}"
						else:
							_, combo = self.getUnambiguousRegionEdgeParameter(edge, "Je1")  # don't need value, only region
							if combo is not None:
								rid0, rid1 = self.regionId(combo[0]), self.regionId(combo[1])
								load_insn, load_cmnt = f"qword ptr [{rid0}_{rid1} + OFFSETOF_REGION_Je1]", f"load Je1_{rid0}_{rid1} (region)"
							elif "Je1" in self.globalKeys:
								load_insn, load_cmnt = f"qword ptr Je1", f"load Je1 (global)"
							else:
								load_insn, load_cmnt = None, None
						load_groups[(load_insn, load_cmnt)].append(edge)
					for i, load_group in enumerate(load_groups.items(), 1):
						load_insn, edges = load_group
						load_insn, load_cmnt = load_insn
						optimization_remove_scalar = False  # TODO: implement optimization. if scalar is const and exactly 1.0
						optimization_neg_scalar = False     # TODO: implement optimization. if scalar is const and exactly -1.0
						src2 += f"\t; [load group {i}]\n"
						tmp_init = False  # tmpx is used as an intermidate for this load group
						for edge in edges:
							# Note: edge in self.edgeIndex may be false if ASM edge array is empty or missing local variables for this edge. This is fine.
							edgelbl = f"edges[{self.edgeIndex[edge]}]" if edge in self.edgeIndex else "edge"
							if load_insn is None:
								src2 += f"; skip. For {edgelbl}, Je1 is not defined at any level (local, region, nor global).\n"
							else:
								phase2 = True
								nid0 = self.nodeId(edge[0])
								nid1 = self.nodeId(edge[1])
								neighbor, _ = Config.neighbor(node, edge)  # just need neighbor. communative operation: doesn't care about direction.
								nindex = self.nodeIndex[neighbor]
								nnid = self.nodeId(neighbor)  # neighbor's node id
								src2 += f"\t; {edgelbl}: {nid0} -> {nid1}\n"
								# Δs_i · f_j:
								fj_isns, fj_cmnt = f"ymmword ptr [nodes + ({nindex})*SIZEOF_NODE + OFFSETOF_FLUX]", f"load f_{nnid} (neighbor)"
								if optimization_remove_scalar:
									if not out_init:
										src2 += f"\t_vdotp {resx}, {resy}, {dsm}, {fj_isns}, {prmx}  ; optimization (Je1*=1), {fj_cmnt}\n"
										out_init = True
									else:
										src2 += f"\t_vdotadd {resx}, {resy}, {dsm}, {fj_isns}, {prmx}  ; optimization (Je1*=1), {fj_cmnt}\n"
								elif optimization_neg_scalar:
									if not out_init:
										src2 += f"\t_vput0 {resx}\n"
										out_init = True
									src2 += f"\t_vndotadds {resx}, {resy}, {dsm}, {fj_isns}, {prmx}  ; optimization (Je1*=-1), {fj_cmnt}\n"
								else:
									if not tmp_init:
										src2 += f"\t_vdotp {tmpx}, {tmpy}, {dsm}, {fj_isns}, {prmx}  ; {fj_cmnt}\n"
										tmp_init = True
									else:
										src2 += f"\t_vdotadd {tmpx}, {tmpy}, {dsm}, {fj_isns}, {prmx}  ; {fj_cmnt}\n"
								# Δf_i · s_j:
								sj_insn, sj_cmnt = f"ymmword ptr [nodes + ({nindex})*SIZEOF_NODE + OFFSETOF_SPIN]", f"load s_{nnid} (neighbor)"
								if optimization_remove_scalar:
									assert out_init  # should be impossible for output to not be initialized above under this optimization case
									src2 += f"\t_vdotadd {resx}, {resy}, {dfi}, {sj_insn}, {prmx}  ; optimization (Je1*=1), {sj_cmnt}\n"
								elif optimization_neg_scalar:
									assert out_init  # should be impossible for output to not be initialized above under this optimization case
									src2 += f"\t_vndotadds {resx}, {resy}, {dfi}, {sj_insn}, {prmx}  ; optimization (Je1*=-1), {sj_cmnt}\n"
								else:
									assert tmp_init  # should be impossible for temp. output to not be initialized above under this unoptimized case
									src2 += f"\t_vdotadd {tmpx}, {tmpy}, {dfi}, {sj_insn}, {prmx}  ; {sj_cmnt}\n"
						if optimization_remove_scalar or optimization_neg_scalar:
							src2 += "\t; optimization (Je1*=1,-1): skip load\n"
						elif load_insn is None:
							src2 += "\t; skip parameter loading for the null load group\n"
						else:
							if not out_init:
								src2 += f"\tvmulsd {resx}, {tmpx}, {load_insn}  ; {load_cmnt}\n"
								out_init = True
							else:
								src2 += f"\tvfmadd231sd {resx}, {tmpx}, {load_insn}  ; {load_cmnt}\n"
					src2 += "\n"
				# compute -ΔU_Jee = Σ_j{Jee Δf_i·f_j}:
				if "Jee" in self.allKeys:
					src2 += "\t; -deltaU_Jee calculation\n"
					# figure out where all neighboring edges load Jee from, and group the common load instructions
					load_groups: dict[tuple[str, str], list] = defaultdict(list)  # dict: (str load_insn, str load_cmnt) -> list[Edge]
					for edge in self.connections(node):
						if "Jee" in self.localEdgeParameters.get(edge, {}):
							eindex = self.edgeIndex[edge]
							nid0 = self.nodeId(edge[0])
							nid1 = self.nodeId(edge[1])
							load_insn, load_cmnt = f"qword ptr [edges + ({eindex})*SIZEOF_EDGE + OFFSETOF_Jee]", f"load Jee_{nid0}_{nid1}"
						else:
							_, combo = self.getUnambiguousRegionEdgeParameter(edge, "Jee")  # don't need value, only region
							if combo is not None:
								rid0, rid1 = self.regionId(combo[0]), self.regionId(combo[1])
								load_insn, load_cmnt = f"qword ptr [{rid0}_{rid1} + OFFSETOF_REGION_Jee]", f"load Jee_{rid0}_{rid1} (region)"
							elif "Jee" in self.globalKeys:
								load_insn, load_cmnt = f"qword ptr Jee", "load Jee (global)"
							else:
								load_insn, load_cmnt = None, None
						load_groups[(load_insn, load_cmnt)].append(edge)
					for i, load_group in enumerate(load_groups.items(), 1):
						load_insn, edges = load_group
						load_insn, load_cmnt = load_insn
						optimization_remove_scalar = False  # TODO: implement optimization. if scalar is const and exactly 1.0
						optimization_neg_scalar = False     # TODO: implement optimization. if scalar is const and exactly -1.0
						src2 += f"\t; [load group {i}]\n"
						tmp_init = False  # tmpx is used as an intermidate for this load group
						for edge in edges:
							# Note: edge in self.edgeIndex may be false if ASM edge array is empty or missing local variables for this edge. This is fine.
							edgelbl = f"edges[{self.edgeIndex[edge]}]" if edge in self.edgeIndex else "edge"
							if load_insn is None:
								src2 += f"; skip. For {edgelbl}, Jee is not defined at any level (local, region, nor global).\n"
							else:
								phase2 = True
								nid0 = self.nodeId(edge[0])
								nid1 = self.nodeId(edge[1])
								neighbor, _ = Config.neighbor(node, edge)  # just need neighbor. communative operation: doesn't care about direction.
								nindex = self.nodeIndex[neighbor]
								nnid = self.nodeId(neighbor)  # neighbor's node id
								src2 += f"\t; {edgelbl}: {nid0} -> {nid1}\n"
								fj_isns, fj_cmnt = f"ymmword ptr [nodes + ({nindex})*SIZEOF_NODE + OFFSETOF_FLUX]", f"load f_{nnid} (neighbor)"
								if optimization_remove_scalar:
									if not out_init:
										src2 += f"\t_vdotp {resx}, {resy}, {dfi}, {fj_isns}, {prmx}  ; optimization (Jee*=1), {fj_cmnt}\n"
										out_init = True
									else:
										src2 += f"\t_vdotadd {resx}, {resy}, {dfi}, {fj_isns}, {prmx}  ; optimization (Jee*=1), {fj_cmnt}\n"
								elif optimization_neg_scalar:
									if not out_init:
										src2 += f"\t_vput0 {resx}\n"
										out_init = True
									src2 += f"\t_vndotadds {resx}, {resy}, {dfi}, {fj_isns}, {prmx}  ; optimization (Jee*=-1), {fj_cmnt}\n"
								else:
									if not tmp_init:
										src2 += f"\t_vdotp {tmpx}, {tmpy}, {dfi}, {fj_isns}, {prmx}  ; {fj_cmnt}\n"
										tmp_init = True
									else:
										src2 += f"\t_vdotadd {tmpx}, {tmpy}, {dfi}, {fj_isns}, {prmx}  ; {fj_cmnt}\n"
						if optimization_remove_scalar or optimization_neg_scalar:
							src2 += "\t; optimization (Jee*=1,-1): skip load\n"
						elif load_insn is None:
							src2 += "\t; skip parameter loading for the null load group\n"
						else:
							if not out_init:
								src2 += f"\tvmulsd {resx}, {tmpx}, {load_insn}  ; {load_cmnt}\n"
								out_init = True
							else:
								src2 += f"\tvfmadd231sd {resx}, {tmpx}, {load_insn}  ; {load_cmnt}\n"
					src2 += "\n"
				# compute -ΔU_b = Σ_j{b ((m'_i·m_j)^2 - (m_i·m_j)^2)}:
				# ASSERT: MUST b the last calculation in phase 2 since it overwrites dfi register
				tmp2x, tmp2y = dfix, dfi  # since dfi register is not needed for phase 3 calculations, and this is the LAST calculation in phase 2
				if "b" in self.allKeys:
					src2 += "\t; -deltaU_b calculation\n"
					# figure out where all neighboring edges load b from, and group the common load instructions
					load_groups: dict[tuple[str, str], list] = defaultdict(list)  # dict: (str load_insn, str load_cmnt) -> list[Edge]
					for edge in self.connections(node):
						if "b" in self.localEdgeParameters.get(edge, {}):
							eindex = self.edgeIndex[edge]
							nid0 = self.nodeId(edge[0])
							nid1 = self.nodeId(edge[1])
							load_insn, load_cmnt = f"qword ptr [edges + ({eindex})*SIZEOF_EDGE + OFFSETOF_b]", f"load b_{nid0}_{nid1}"
						else:
							_, combo = self.getUnambiguousRegionEdgeParameter(edge, "b")  # don't need value, only region
							if combo is not None:
								rid0, rid1 = self.regionId(combo[0]), self.regionId(combo[1])
								load_insn, load_cmnt = f"qword ptr [{rid0}_{rid1} + OFFSETOF_REGION_b]", f"load b_{rid0}_{rid1} (region)"
							elif "b" in self.globalKeys:
								load_insn, load_cmnt = f"qword ptr b", f"load b (global)"
							else:
								load_insn, load_cmnt = None, None
						load_groups[(load_insn, load_cmnt)].append(edge)
					for i, load_group in enumerate(load_groups.items(), 1):
						load_insn, edges = load_group
						load_insn, load_cmnt = load_insn
						optimization_remove_scalar = False  # TODO: implement optimization. if scalar is const and exactly 1.0
						optimization_neg_scalar = False     # TODO: implement optimization. if scalar is const and exactly -1.0
						src2 += f"\t; [load group {i}]\n"
						tmp_init = False  # tmpx is used as an intermidate for this load group
						for edge in edges:
							# Note: edge in self.edgeIndex may be false if ASM edge array is empty or missing local variables for this edge. This is fine.
							edgelbl = f"edges[{self.edgeIndex[edge]}]" if edge in self.edgeIndex else "edge"
							if load_insn is None:
								src2 += f"; skip. For {edgelbl}, b is not defined at any level (local, region, nor global).\n"
							else:
								phase2 = True
								nid0 = self.nodeId(edge[0])
								nid1 = self.nodeId(edge[1])
								neighbor, _ = Config.neighbor(node, edge)  # just need neighbor. communative operation: doesn't care about direction.
								nindex = self.nodeIndex[neighbor]
								nnid = self.nodeId(neighbor)  # neighbor's node id
								src2 += f"\t; {edgelbl}: {nid0} -> {nid1}\n"
								src2 += f"\tvmovapd {sfmj}, ymmword ptr [nodes + ({nindex})*SIZEOF_NODE + OFFSETOF_SPIN]          ; load s_{nnid} (neighbor)\n"
								if flux_mode:
									src2 += f"\tvaddpd {sfmj}, {sfmj}, ymmword ptr [nodes + ({nindex})*SIZEOF_NODE + OFFSETOF_FLUX]   ; m_{nnid} = s_{nnid} + f_{nnid}\n"
								if optimization_remove_scalar:
									if not out_init:
										src2 += f"\t_vdotp {resx}, {resy}, {m1i}, {sfmj}, {prmx}  ; optimization (b*=1), ({m1i}, {sfmj}) -> {resx}\n"
										src2 += f"\tvmulsd {resx}, {resx}, {resx}                 ; {resx}**2\n"
										src2 += f"\t_vdotp {tmpx}, {tmpy}, {smi}, {sfmj}, {prmx}  ; ({smi}, {sfmj}) -> {tmpx}\n"
										src2 += f"\tvfnmadd231sd {resx}, {tmpx}, {tmpx}           ; {resx}**2 - {tmpx}**2\n"
										out_init = True
									else:
										src2 += f"\t_vdotp {tmpx}, {tmpy}, {m1i}, {sfmj}, {prmx}  ; optimization (b*=1), ({m1i}, {sfmj}) -> {tmpx}\n"
										src2 += f"\tvfmadd231sd {resx}, {tmpx}, {tmpx}            ; + {tmpx}**2\n"
										src2 += f"\t_vdotp {tmpx}, {tmpy}, {smi}, {sfmj}, {prmx}  ; ({smi}, {sfmj}) -> {tmpx}\n"
										src2 += f"\tvfnmadd231sd {resx}, {tmpx}, {tmpx}           ; - {tmpx}**2\n"
								elif optimization_neg_scalar:
									if not out_init:
										src2 += f"\t_vdotp {resx}, {resy}, {smi}, {sfmj}, {prmx}  ; optimization (b*=-1), ({smi}, {sfmj}) -> {resx}\n"
										src2 += f"\tvmulsd {resx}, {resx}, {resx}                 ; {resx}**2\n"
										src2 += f"\t_vdotp {tmpx}, {tmpy}, {m1i}, {sfmj}, {prmx}  ; ({m1i}, {sfmj}) -> {tmpx}\n"
										src2 += f"\tvfnmadd231sd {resx}, {tmpx}, {tmpx}           ; {resx}**2 - {tmpx}**2\n"
										out_init = True
									else:
										src2 += f"\t_vdotp {tmpx}, {tmpy}, {m1i}, {sfmj}, {prmx}  ; optimization (b*=-1), ({m1i}, {sfmj}) -> {tmpx}\n"
										src2 += f"\tvfnmadd231sd {resx}, {tmpx}, {tmpx}           ; - {tmpx}**2\n"
										src2 += f"\t_vdotp {tmpx}, {tmpy}, {smi}, {sfmj}, {prmx}  ; ({smi}, {sfmj}) -> {tmpx}\n"
										src2 += f"\tvfmadd231sd {resx}, {tmpx}, {tmpx}            ; + {tmpx}**2\n"
								else:
									src2 += f"\t_vdotp {tmp2x}, {tmp2y}, {m1i}, {sfmj}, {prmx}  ; ({m1i}, {sfmj}) -> {tmpx}\n"
									if not tmp_init:
										src2 += f"\tvmulsd {tmpx}, {tmp2x}, {tmp2x}             ; = {tmpx} ** 2\n"
										tmp_init = True
									else:
										src2 += f"\tvfmadd231sd {tmpx}, {tmp2x}, {tmp2x}        ; += {tmp2x} ** 2\n"
									src2 += f"\t_vdotp {tmp2x}, {tmp2y}, {smi}, {sfmj}, {prmx}  ; ({smi}, {sfmj}) -> {tmpx}\n"
									assert tmp_init  # must be initialized here
									src2 += f"\tvfnmadd231sd {tmpx}, {tmp2x}, {tmp2x}           ; -= {tmpx} ** 2\n"
						if optimization_remove_scalar or optimization_neg_scalar:
							src2 += "\t; optimization (b*=1,-1): skip load\n"
						elif load_insn is None:
							src2 += "\t; skip parameter loading for the null load group\n"
						else:
							if not out_init:
								src2 += f"\tvmulpd {resx}, {tmpx}, {load_insn}  ; {load_cmnt}\n"
								out_init = True
							else:
								src2 += f"\tvfmadd231sd {resx}, {tmpx}, {load_insn}  ; {load_cmnt}\n"
					src2 += "\n"
				# Phase 3 compute (Δm_i) -> -ΔU_(B, D):
				phase3: bool = False  # does phase 3 contain any code?
				src3 = StrJoiner()    # buffer phase 3 src to emit after load
				# compute -ΔU_B = B ⋅ Δm_i:
				if "B" in self.allKeys:
					src3 += "\t; compute -delta_U_B\n"
					# where is B defined?
					load_insn, load_cmnt = None, None  # How should this node be loaded?
					if "B" in self.localNodeParameters.get(node, {}):
						load_insn, load_cmnt = f"ymmword ptr [nodes + ({index})*SIZEOF_NODE + OFFSETOF_B]", f"load B_{nid} (local)"
					else:
						_, region = self.getUnambiguousRegionNodeParameter(node, "B")  # don't need value, only region
						if region is not None:
							rid = self.regionId(region)
							load_insn, load_cmnt = f"ymmword ptr [{rid} + OFFSETOF_REGION_B]", f"load B_{rid} (region)"
						elif "B" in self.globalKeys:
							load_insn, load_cmnt = f"ymmword ptr B", "load B (global)"
					if load_insn is None:
						src3 += f"\t; skip. For this node, B is not defined at any level (local, region, nor global).\n\n"
					else:
						phase3 = True
						if not out_init:
							src3 += f"\t_vdotp {resx}, {resy}, {dsm}, {load_insn}, {sfmjx}  ; {load_cmnt}\n\n"  # can use sfmj as temp for local parameters
							out_init = True
						else:
							src3 += f"\t_vdotadd {resx}, {resy}, {dsm}, {load_insn}, {sfmjx}  ; {load_cmnt}\n\n"  # can use sfmj as temp for local parameters
				# compute -ΔU_D:
				if "D" in self.allKeys:
					src3 += "\t; -deltaU_D calculation\n"
					# figure out where all neighboring edges load D from, and group the common load instructions
					load_groups: dict[tuple[str, str], list] = defaultdict(list)  # dict: (str load_insn, str load_cmnt) -> list[Edge]
					for edge in self.connections(node):
						if "D" in self.localEdgeParameters.get(edge, {}):
							eindex = self.edgeIndex[edge]
							nid0 = self.nodeId(edge[0])
							nid1 = self.nodeId(edge[1])
							load_insn, load_cmnt = f"ymmword ptr [edges + ({eindex})*SIZEOF_EDGE + OFFSETOF_D]", f"load D_{nid0}_{nid1}"
						else:
							_, combo = self.getUnambiguousRegionEdgeParameter(edge, "D")  # don't need value, only region
							if combo is not None:
								rid0, rid1 = self.regionId(combo[0]), self.regionId(combo[1])
								load_insn, load_cmnt = f"ymmword ptr [{rid0}_{rid1} + OFFSETOF_REGION_D]", f"load D_{rid0}_{rid1} (region)"
							elif "D" in self.globalKeys:
								load_insn, load_cmnt = f"ymmword ptr D", f"load D (global)"
							else:
								load_insn, load_cmnt = None, None
						load_groups[(load_insn, load_cmnt)].append(edge)
					for i, load_group in enumerate(load_groups.items(), 1):
						load_insn, edges = load_group
						load_insn, load_cmnt = load_insn
						src3 += f"\t; [load group {i}]\n"
						tmp_init = False  # tmpx is used as an intermidate for this load group
						for edge in edges:
							# Note: edge in self.edgeIndex may be false if ASM edge array is empty or missing local variables for this edge. This is fine.
							edgelbl = f"edges[{self.edgeIndex[edge]}]" if edge in self.edgeIndex else "edge"
							if load_insn is None:
								src3 += f"\t; skip. For {edgelbl}, D is not defined at any level (local, region, nor global).\n"
							else:
								phase3 = True
								nid0 = self.nodeId(edge[0])
								nid1 = self.nodeId(edge[1])
								neighbor, direction = Config.neighbor(node, edge)  # non-communative operation: need direction!
								nindex = self.nodeIndex[neighbor]
								nnid = self.nodeId(neighbor)  # neighbor's node id
								src3 += f"\t; {edgelbl}: {nid0} -> {nid1}\n"
								if direction == 0:
									src3 += "; skipping self-loop since cross product is 0\n"
								else:
									src3 += f"\tvmovapd {sfmj}, ymmword ptr [nodes + ({nindex})*SIZEOF_NODE + OFFSETOF_SPIN]        ; load s_{nnid} (neighbor)\n"
									if flux_mode:
										src3 += f"\tvaddpd {sfmj}, {sfmj}, ymmword ptr [nodes + ({nindex})*SIZEOF_NODE + OFFSETOF_FLUX]   ; m_{nnid} = s_{nnid} + f_{nnid}\n"
									if not tmp_init:
										if direction > 0:  # forward edge: node == edge[0]
											src3 += f"\t_vcrossp {tmpy}, {dsm}, {sfmj}, {smi}, {fm1}\n"  # smi and fm1 are unused durring phase 3
										else:
											assert direction < 0
											src3 += f"\t_vcrossp {tmpy}, {sfmj}, {dsm}, {smi}, {fm1}\n"  # smi and fm1 are unused durring phase 3
										tmp_init = True
									else:
										if direction > 0:  # forward edge: node == edge[0]
											src3 += f"\t_vcrossadd {tmpy}, {dsm}, {sfmj}, {smi}, {fm1}\n"  # smi and fm1 are unused durring phase 3
										else:
											assert direction < 0
											src3 += f"\t_vcrossadd {tmpy}, {sfmj}, {dsm}, {smi}, {fm1}\n"  # smi and fm1 are unused durring phase 3
										tmp_init = True
						if tmp_init:
							if not out_init:
								src3 += f"\t_vdotp {resx}, {resy}, {tmpy}, {load_insn}, {smix}  ; {load_cmnt}\n"
								out_init = True
							else:
								src3 += f"\t_vdotadd {resx}, {resy}, {tmpy}, {load_insn}, {smix}  ; {load_cmnt}\n"
					src3 += "\n"
				# commit phase 1
				if phase1 or phase2 or phase3:
					src += "\t; Phase 1:\n"
					src += f"\tvmovapd {smi}, ymmword ptr [nodes + ({index})*SIZEOF_NODE + OFFSETOF_SPIN]  ; load s_i\n"
					if flux_mode:
						src += f"\tvmovapd {fm1}, ymmword ptr [nodes + ({index})*SIZEOF_NODE + OFFSETOF_FLUX]  ; load f_i\n"
				else:
					src += "\t; Phase 1: (skip)\n"
				src += "\n" + str(src1)  # actual ASM (or comments)
				# commit phase 2
				if phase2 or phase3:
					src += "\t; Phase 2:\n"
					if phase2:
						src += f"\tvsubpd {dsm}, {s1i}, {smi}  ; \\Delta s_i = s'_i - s_i\n"  # not needed for phase 3
					if flux_mode:
						if phase2:  # not needed for phase 3
							src += f"\tvsubpd {dfi}, {f1i}, {fm1}  ; \\Detla f = f'_i - f_i\n"
						src += f"\tvaddpd {smi}, {smi}, {fm1}  ; m_i = s_i + f_i\n"
						src += f"\tvaddpd {m1i}, {s1i}, {f1i}  ; m'_i = s'_i + f'_i\n"
					else:
						src += f"\t; ({smi}) m_i = s_i since f_i = 0\n"
						src += f"\t; ({m1i}) m'_i = s'_i since f'_i = 0\n"
				else:
					src += "\t; Phase 2: (skip)\n"
				src += "\n" + str(src2)
				# commit phase 3
				if phase3:
					src += "\t; Phase 3:\n"
					if flux_mode:
						src += f"\tvsubpd {dsm}, {m1i}, {smi}  ; \\Delta m_i = m'_i - m_i\n\n"
					else:
						src += f"\t; ({dsm}) \\Delta m_i = \\Delta s_i since \\Delta f_i = 0\n\n"
				else:
					src += "\t; Phase 3: (skip)\n\n"
				src += str(src3)
				# return:
				if not out_init:
					src += f"\tvxorpd {resx}, {resx}, {resx}  ; return 0.0\n"  # fall back in case there are no parameters set for this node
				if "deltaU_ret_dump" in self.debug:
					src += "\t_dumpreg\n"  # DEBUG: make sure xmm0 (ΔU) matches python calculated "u" for each parameter
				src += "\tret\n"
				src += f"{proc_id} ENDP\n\n"
				exports.append((proc_id, False))
		
		tqdm_proc = tqdm(total=5, desc="[Compiling] Writing ASM .code (other PROC)") if progress_bars else None
		def tqdm_proc_update(n=1):
			if tqdm_proc is not None:  tqdm_proc.update(n)

		# metropolis PROC
		src += "; Helpers for calculating random unit vectors (Marsaglia's method)\n"
		src += "_gen_omega MACRO o, one, temp\n"
		if prng.startswith("xoshiro256"):  # TODO: support other PRNGs
			macro = prng.replace("*", "s").replace("+", "p")
			src += f"\t_v{macro} o, ymm12, ymm13, ymm14, ymm15, temp\n"
			src += "\t; assert one == [1.0, 1.0, 1.0, 1.0]\n"
			src += "\t_vomega o, o, one   ; [0, 1)\n"
		src += "ENDM\n\n"
		src += "_gen_ws MACRO o, w, s, one, temp\n"
		src += "\t_gen_omega o, one, temp\n"
		src += "\tvaddpd w, o, o      ; mul by 2 -> [0, 2)\n"
		src += "\tvsubpd w, w, one    ; sub by 1 -> [-1, 1); w = [u_1, v_1, u_2, v_2]\n"
		src += "\tvmulpd s, w, w   ; Hadamard product: [u_1^2, v_1^2, ...]\n"
		src += "\tvhaddpd s, s, s  ; Radius squared: [s_1, s_1, s_2, s_2] where s_i = u_i^2 + v_i^2\n"
		src += "ENDM\n\n"
		src += "_calc_xyz MACRO w, z, s, one\n"
		src += "\tvaddpd w, w, w           ; 2w\n"
		src += "\tvsubpd z, one, s         ; 1 - s\n"
		src += "\tvsqrtpd z, z             ; sqrt(1 - s)\n"
		src += "\tvmulpd w, w, z           ; 2w * sqrt(1 - s) = [x_1, y_1, x_2, y_2] -> x_i = 2u_i * sqrt(1-s_i) and y_i = 2v_i * sqrt(1-s)\n"
		src += "\tvaddpd s, s, s           ; 2s\n"
		src += "\tvsubpd z, one, s         ; 1 - 2s = [z_1, z_1, z_2, z_2] -> z_i = 1 - 2s_i\n"
		src += "\tvpxor s, s, s            ; [0, 0, 0, 0]\n"
		src += "\tvblendpd z, z, s, 1010b  ; [z_1, 0, z_2, 0]\n"
		src += "ENDM\n\n"
		src += "; Runs the standard metropolis algorithm\n"
		src += "; @param RCX (uint64) - number of iterations\n"
		src += "; @return (void)\n"
		src += "PUBLIC metropolis\n"
		src += "metropolis PROC\n"
		src += "\t; *rax: scratch reg.\n"
		src += "\t;  rcx: loop counter\n"
		src += "\t;  rdx: index[3] (or index[2] in TAIL)\n"
		src += "\t;  rbx: \n"
		src += "\t;  rsp: (stack pointer)\n"
		src += "\t;  rbp: (base pointer)\n"
		src += "\t;  *rsi: scratch reg.\n"
		src += "\t;  rdi: \n"
		src += "\t;  r8:  index[0]\n"
		src += "\t;  r9:  index[1]\n"
		src += "\t;  r10: index[2]\n"
		src += "\t;  r11: MUTABLE_NODE_COUNT\n"
		src += "\t;  ... \n"
		src += "\t;  ymm0: -\\DeltaU\n"
		src += "\t;  ymm1: new spin, s'\n"
		src += "\t;  ymm2: new flux, f'\n"
		src += "\t;  ...\n"
		src += "\t;  ymm11: vectorized ln(p)\n"
		src += "\t;  ymm12: vectorized PNRG state[0]\n"
		src += "\t;  ymm13: vectorized PRNG state[1]\n"
		src += "\t;  ymm14: vectorized PRNG state[2]\n"
		src += "\t;  ymm15: vectorized PRNG state[3]\n\n"
		# preamble
		src += "\t; preamble: save non-volitile registers\n"
		src += "\tpush rbp\n"
		src += "\tmov rbp, rsp\n"
		src += "\tsub rsp, (10)*16 + 8  ; space for the 10 non-volitile XMM6-15 reg. and RSI\n"
		for i in range(10):  # XMM6-15
			src += f"\tvmovdqu xmmword ptr [rbp - ({i+1})*16], xmm{6+i}\n"
		src += f"\tmov qword ptr [rbp - (10)*16 - 8], rsi\n"
		src += "\n"
		# load PRNG state, and other constants
		if prng.startswith("xoshiro256"):  # TODO: support other PRNGs
			src += f"\t; load vectorized PRNG ({prng}) state into YMM12, YMM13, YMM14, YMM15; and load other constants\n"
			src += "\tvmovdqa ymm12, ymmword ptr [prng_state + (0)*32]\n"
			src += "\tvmovdqa ymm13, ymmword ptr [prng_state + (1)*32]\n"
			src += "\tvmovdqa ymm14, ymmword ptr [prng_state + (2)*32]\n"
			src += "\tvmovdqa ymm15, ymmword ptr [prng_state + (3)*32]\n"
		src += "\tmov r11, MUTABLE_NODE_COUNT ; load mutable nodes array size\n"
		# loop metropolis algo. in batchs of 4 (`True`) until TAIL (`False`)
		for batch4 in [True, False]:
			if batch4:
				regis = ["r8", "r9", "r10", "rdx"]
				src += "\tLOOP_START:  ; process nodes in batchs of 4\n"
				src += "\t\tcmp rcx, 4\n"
				src += "\t\tjb LOOP_END  ; while ((unsigned) rcx >= 4)\n\n"
			else:
				regis = ["r8", "r9", "rdx"]
				src += "\tTAIL_START:  ; Last 0-3 nodes\n"
				src += "\t\tcmp rcx, 0\n"
				src += "\t\tje TAIL_END\n\n"
			# select (3 or) 4 random nodes
			src += f"\t\t; select {len(regis)} random indices for mutable nodes -> {regis}\n"
			if prng.startswith("xoshiro256"):  # TODO: support other PRNGs
				macro = prng.replace("*", "s").replace("+", "p")
				src += f"\t\t_v{macro} ymm0, ymm12, ymm13, ymm14, ymm15, ymm10  ; [a, b, c, d]\n"
				src += "\t\tvmovq rax, xmm0     ; extract a\n"
				src += "\t\tmul r11             ; rdx:rax = rax * r11 = random * NODE_COUNT\n"
				src += "\t\tmov r8, rdx         ; save 1st future random index (r8)\n"
				src += "\t\t_vpermj ymm0, ymm0  ; [b, a, c, d]\n"
				src += "\t\tvmovq rax, xmm0     ; extract b\n"
				src += "\t\tmul r11\n"
				src += "\t\tmov r9, rdx         ; save 2nd future random index (r9)\n"
				src += "\t\t_vpermk ymm0, ymm0  ; [c, d, b, a]\n"
				src += "\t\tvmovq rax, xmm0     ; extract c\n"
				src += "\t\tmul r11"
				if batch4:
					src += "\n"
					src += "\t\tmov r10, rdx        ; save 3rd future random index (r10)\n"
					src += "\t\t_vpermj ymm0, ymm0  ; [d, c, b, a]\n"
					src += "\t\tvmovq rax, xmm0     ; extract d\n"
					src += "\t\tmul r11             ; save 4th future random index (rdx)\n\n"
				else:
					src += "             ; save 3rd future random index (rdx)\n\n"
			# generate 4 ω ∈ [0, 1) for probabilistic branching (ymm11)
			one = "ymm6"
			src += "\t\t; generate 4 \\omega \\in [0, 1) for probabilistic branching (ymm11)\n"
			src += "\t\t_vxoshiro256ss ymm11, ymm12, ymm13, ymm14, ymm15, ymm10       ; (vectorized) uint64\n"
			src += f"\t\t_vones {one}                                                   ; [1.0, 1.0, 1.0, 1.0]\n"
			src += f"\t\t_vomega ymm11, ymm11, {one}                                    ; (vectorized) \\omega \\in [0, 1)\n"
			src += f"\t\t_vln ymm11, ymm11, {one}, ymm7, ymm8, ymm9, ymm10, xmm10, rax  ; (vectorized) ln(\\omega) \\in [-inf, 0)\n\n"
			# (repeat 3 or 4 times)
			for regi in regis:
				pad = " " * (3 - len(regi))
				# pick uniformally random new state for the node
				wxys = "ymm1"  # [u_1, v_1, u_2, v_2] -> [x_1, y_1, x_2, y_2] -> s'
				flux = "ymm2"  # f'
				zmsk = "ymm3"  # comparision bit-mask -> [z_1, 0, z_2, 0]
				s = "ymm4"     # [s_1, s_1, s_2, s_2] where s_i = (u_i)^2 + (v_i)^2
				omega = "ymm5" if "F" in self.allKeys else "ymm1"  # contains the PRNG random float [0, 1.0) incase it goes unused
				lbl_suffix = f"{regi.upper()}_{["TAIL", "BATCH4"][int(batch4)]}"
				padl = " " * (len(regi) + 1 + 6 - len(lbl_suffix))
				MARSAGLIA_START_2 = f"MARSAGLIA_START_2_{lbl_suffix}"
				MARSAGLIA_START_1 = f"MARSAGLIA_START_1_{lbl_suffix}"
				MARSAGLIA_END = f"MARSAGLIA_END_{lbl_suffix}"
				MARSAGLIA_END_LO = f"MARSAGLIA_END_LO_{lbl_suffix}" if "F" in self.allKeys else MARSAGLIA_END  # end with "leftover" omegas
				num = regis.index(regi)
				F = ["G", "F"][int(batch4)]
				S = ["T", "S"][int(batch4)]
				F1 = f"{F}{2*num+1}"
				F2 = f"{F}{2*num+2}"
				S1 = f"{S}{2*num+1}"
				S2 = f"{S}{2*num+2}"
				src += f"\t\t; pick uniformally random new state for node [{regi}] (Marsaglia's method)\n"
				if regis.index(regi) == 0:
					src += f"\t\t                                          ; assert {one} == [1.0, 1.0, 1.0, 1.0]\n"
				else:
					src += f"\t\t_vones {one}                               ; [1.0, 1.0, 1.0, 1.0]\n"
				if "F" in self.allKeys:
					src += f"\t\t{MARSAGLIA_START_2}:             {pad}{padl}; 2 vectors, f' -> {flux}, s' -> {wxys}\n"
					src += f"\t\t\t_gen_ws {wxys}, {wxys}, {s}, {one}, ymm10\n"
					src += f"\t\t\tvcmppd {zmsk}, {s}, {one}, 11h          ; {s} < {one}\n"
					src += f"\t\t\tvmovmskpd rax, {zmsk}                   ; rax = 0...bbaa where a = (s_1 < 1.0) and b = (s_2 < 1.0)\n"
					src += f"\t\t\t{F1}:\ttest rax, 0100b                   ; test bit (b)\n"
					src += f"\t\t\t\tjz {F2}                             ; !b -> s_2 >= 1.0\n"
					src += f"\t\t\t\t_calc_xyz {wxys}, {zmsk}, {s}, {one}\n"
					src += f"\t\t\t\tvperm2f128 {flux}, {wxys}, {zmsk}, 31h  ; [x_2, y_2, z_2, 0] = f'\n"
					src += "\t\t\t\ttest rax, 0001b                   ; test bit (a)\n"
					src += f"\t\t\t\tjz {MARSAGLIA_START_1}   {pad}{padl}; !a -> s_1 >= 1.0\n"
					src += f"\t\t\t\tvperm2f128 {wxys}, {wxys}, {zmsk}, 20h  ; [x_1, y_1, z_1, 0] = s'\n"
					src += f"\t\t\t\tjmp {MARSAGLIA_END}\n"
					src += f"\t\t\t{F2}:\ttest rax, 0001b                   ; test bit (a)\n"
					src += f"\t\t\t\tjz {MARSAGLIA_START_2}   {pad}{padl}; !a -> s_1 >= 1.0\n"
					src += f"\t\t\t\t_calc_xyz {wxys}, {zmsk}, {s}, {one}\n"
					src += f"\t\t\t\tvperm2f128 {flux}, {wxys}, {zmsk}, 20h  ; [x_1, y_1, z_1, 0] -> f'\n"
					src += f"\t\t\t\t; jmp {MARSAGLIA_START_1}\n"
				# either no flux. or already haveflux. only need s'
				src += f"\t\t{MARSAGLIA_START_1}:             {pad}{padl}; only 1 vector, s' -> {wxys}\n"
				src += f"\t\t\t_gen_ws {omega}, {wxys}, {s}, {one}, ymm10\n"
				src += f"\t\t\tvcmppd {zmsk}, {s}, {one}, 11h          ; {s} < {one}\n"
				src += f"\t\t\tvmovmskpd rax, {zmsk}                   ; rax = 0...bbaa where a = (s_1 < 1.0) and b = (s_2 < 1.0)\n"
				src += f"\t\t\t{S1}:\ttest rax, 0100b                   ; test bit (b)\n"
				src += f"\t\t\t\tjz {S2}                             ; !b -> s_2 >= 1.0\n"
				src += f"\t\t\t\t_calc_xyz {wxys}, {zmsk}, {s}, {one}\n"
				src += f"\t\t\t\tvperm2f128 {wxys}, {wxys}, {zmsk}, 31h  ; [x_2, y_2, z_2, 0] = s'\n"
				src += f"\t\t\t\tjmp {MARSAGLIA_END_LO}\n"
				src += f"\t\t\t{S2}:\ttest rax, 0001b                   ; test bit (a)\n"
				src += f"\t\t\t\tjz {MARSAGLIA_START_1}   {pad}{padl}; !a -> s_1 >= 1.0\n"
				src += f"\t\t\t\t_calc_xyz {wxys}, {zmsk}, {s}, ymm6\n"
				src += f"\t\t\t\tvperm2f128 {wxys}, {wxys}, {zmsk}, 20h  ; [x_1, y_1, z_1, 0] = s'\n"
				src += f"\t\t{MARSAGLIA_END}:\n"
				# scale by S and F
				spin = wxys
				flux = flux
				coef = "ymm3"   # scalar S or F broadcast, e.g. [S, S, S, S]
				msk = "xmm3"    # Note: vgather mask used before coef. overlap okay
				addr = "xmm4"   # Addresses [&S, &F] IMPORTANT: Can *not* not overlap with dest `sf` nor mask `msk`. Will cause runtime #UD fault!
				omegaY = omega  # pseudo random ω for randomizing 0 <= |f'| < F
				omegaX = omega.replace("y", "x")
				one = one       # "ymm6"
				sf = "xmm6"     # scalars [S, F] packed; OVERLAPS with {one}
				# TODO: (optimization) skip for S=1.0 and/or F=1.0 (Note: S, F >= 0)
				if "F" in self.allKeys:
					src += "\t\t; generate \\omega coef. for randomizing |f'| = \\omega * F\n"
					src += f"\t\t_gen_omega {omega}, {one}, ymm10\n"
					src += f"\t\t{MARSAGLIA_END_LO}:  ; use \"leftover\" \\omega in {omega}\n"
					src += f"\t\t; scale s' ({spin}) and f' ({flux})\n"
					src += f"\t\tlea rax, SFref\n"
					src += f"\t\tmov rsi, {regi}                           {pad}; calculate array offset\n"
					src += f"\t\tshl rsi, 4                             ; mul 16\n"
					src += f"\t\tvmovapd {addr}, xmmword ptr [rax + rsi]  ; pointers (double*[]) to [S, F]\n"
					src += f"\t\txor rax, rax                           ; 0 base for absolute vgather\n"
					src += f"\t\tvpcmpeqq {msk}, {msk}, {msk}              ; load mask (all 1's)\n"
					src += f"\t\tvgatherqpd {sf}, [rax + {addr}], {msk}\n"
					src += f"\t\tvbroadcastsd {coef}, {sf}                ; {coef} = [S, S, S, S]\n"
					src += f"\t\tvmulpd {spin}, {spin}, {coef}                ; scale {spin} by S\n"
					src += f"\t\t_vpermj {sf}, {sf}                     ; [F, S]\n"
					src += f"\t\tvbroadcastsd {coef}, {sf}                ; {coef} = [F, F, F, F]\n"
					src += f"\t\tvmulpd {flux}, {flux}, {coef}                ; scale {flux} by F\n"
					src += f"\t\tvbroadcastsd {coef}, {omegaX}                 ; {coef} = [\\omega[0], \\omega[0], \\omega[0], \\omega[0]]\n"
					src += f"\t\tvmulpd {flux}, {flux}, {coef}                ; scale {flux} by \\omega\n"
				else:
					src += f"\t\t; scale s' ({spin})\n"
					src += f"\t\tlea rax, Sref\n"
					src += f"\t\tmov rax, qword ptr [rax + {regi}*8]   {pad}; pointer (double*) to S\n"
					src += f"\t\tvbroadcastsd {coef}, qword ptr [rax]  ; [S, S, S, S]\n"
					src += f"\t\tvmulpd {spin}, {spin}, {coef}  ; scale {spin} by S\n"
				src += "\n"
				# compute -ΔU for the propsed state change
				src += "\t\t; compute -deltaU for the proposed state change\n"
				src += "\t\tlea rax, deltaU         ; pointer to array of function pointers\n"
				src += f"\t\tmov rax, [rax + {regi}*8]  {pad}; deltaU[{regi}], dereferenced to get the actual function pointer\n"
				src += f"\t\tcall rax                ; args: ({wxys}, {flux}?) -> return xmm0\n\n"
				# compute probability factor, ω < p = e^{-ΔU/kT} -> kT*ln(ω) < -ΔU
				ln_omegaX, ln_omegaY = "xmm11", "ymm11"
				kT = s.replace("y", "x")
				fact = coef.replace("y", "x")  # stores probability factor, kT*ln(ω)
				src += f"\t\t; compute probability factor ({fact}), \\omega < p = e^(-deltaU/kT) -> kT*ln(\\omega) < -deltaU\n"
				src += "\t\tlea rax, kTref\n"
				src += f"\t\tmov rax, qword ptr [rax + {regi}*8]  {pad}; double* -> rax\n"
				src += f"\t\tvmovq {kT}, qword ptr [rax]       ; {kT} = [kT, ?, 0, 0]\n"
				if regis.index(regi) == 0:
					src += f"\t\tvmulsd {fact}, {ln_omegaX}, {kT}          ; kT * (scalar) [(a), b, c, d] = kT * a\n\n"
				else:
					if regis.index(regi) == 1:
						src += f"\t\t_vpermj {ln_omegaY}, {ln_omegaY}              ; [b, a, c, d]\n"
						src += f"\t\tvmulsd {fact}, {ln_omegaX}, {kT}          ; kT * b\n\n"
					elif regis.index(regi) == 2:
						src += f"\t\t_vpermk {ln_omegaY}, {ln_omegaY}              ; [c, d, b, a]\n"
						src += f"\t\tvmulsd {fact}, {ln_omegaX}, {kT}          ; kT * c\n\n"
					elif regis.index(regi) == 3:
						src += f"\t\t_vpermj {ln_omegaY}, {ln_omegaY}              ; [d, c, b, a]\n"
						src += f"\t\tvmulsd {fact}, {ln_omegaX}, {kT}          ; kT * d\n\n"
				# (maybe) change the node's state
				spin = spin
				flux = flux
				SKIP = f"SKIP_{regi.upper()}_{["TAIL", "BATCH4"][int(batch4)]}"
				src += "\t\t; (maybe) change the node's state\n"
				src += f"\t\tvucomisd {fact}, xmm0  ; compare {fact} - xmm0\n"
				src += f"\t\tjae {SKIP}  {pad}; kT * ln(\\omega) >= -deltaU\n"
				src += "\t\tlea rax, nodes\n"
				if is_pow2(self.SIZEOF_NODE):
					src += f"\t\tshl {regi}, {self.SIZEOF_NODE.bit_length() - 1}  ; mul SIZEOF_NODE ({self.SIZEOF_NODE})\n"
				else:
					src += f"\t\timul {regi}, SIZEOF_NODE\n"
				src += f"\t\tvmovapd [rax + {regi} + OFFSETOF_SPIN], {spin}  {pad}; update s' -> spin\n"
				if "F" in self.allKeys:
					src += f"\t\tvmovapd [rax + {regi} + OFFSETOF_FLUX], {flux}  {pad}; update f' -> flux\n"
				src += f"\t\t{SKIP}:\n\n"
				# parameter modification(s); e.g. global.B -= dB
				if not "dkT" in self.allKeys:
					src += "\t\t; (skip) update kT (linearly)\n\n"
				else:
					kT = "xmm10"
					src += "\t\t; update kT (linearly)\n"
					for node in self.mutableNodes:
						params = self.localNodeParameters.get(node, {})
						if "dkT" in params:
							idx = self.nodeIndex[node]
							src += f"\t\tvmovsd {kT}, [nodes + SIZEOF_NODE*({idx}) + OFFSETOF_kT]  ; node[{idx}], id={self.nodeId(node)}\n"
							src += f"\t\tvaddsd {kT}, {kT}, [nodes + SIZEOF_NODE*({idx}) + OFFSETOF_dkT]\n"
							src += f"\t\tvmovsd [nodes + SIZEOF_NODE*({idx}) + OFFSETOF_kT], {kT}\n"
					for region in self.regions:
						params = self.regionNodeParameters.get(region, {})
						if "dkT" in params:
							rid = self.regionId(region)
							src += f"\t\tvmovsd {kT}, [{rid} + OFFSETOF_REGION_kT]  ; region, {rid}\n"
							src += f"\t\tvaddsd {kT}, {kT}, [{rid} + OFFSETOF_REGION_dkT]\n"
							src += f"\t\tvmovsd [{rid} + OFFSETOF_REGION_kT], {kT}\n"
					if "dkT" in self.globalParameters:
						src += f"\t\tvmovsd {kT}, kT;  global\n"
						src += f"\t\tvaddsd {kT}, {kT}, dkT\n"
						src += f"\t\tvmovsd kT, {kT}\n"
					src += "\n"
				if not "dB" in self.allKeys:
					src += "\t\t; (skip) update B (linearly)\n\n"
				else:
					B = "ymm10"
					src += "\t\t; update B (linearly)\n"
					for node in self.mutableNodes:
						params = self.localNodeParameters.get(node, {})
						if "dB" in params:
							idx = self.nodeIndex[node]
							src += f"\t\tvmovapd {B}, ymmword ptr [nodes + SIZEOF_NODE*({idx}) + OFFSETOF_B];  node[{idx}], id={self.nodeId(node)}\n"
							src += f"\t\tvaddpd {B}, {B}, ymmword ptr [nodes + SIZEOF_NODE*({idx}) + OFFSETOF_dB]\n"
							src += f"\t\tvmovapd ymmword ptr [nodes + SIZEOF_NODE*({idx}) + OFFSETOF_B], {B}\n"
					for region in self.regions:
						params = self.regionNodeParameters.get(region, {})
						if "dB" in params:
							rid = self.regionId(region)
							src += f"\t\tvmovapd {B}, ymmword ptr [{rid} + OFFSETOF_REGION_B];  region, {rid}\n"
							src += f"\t\tvaddpd {B}, {B}, ymmword prt [{rid} + OFFSETOF_REGION_dB]\n"
							src += f"\t\tvmovapd ymmword ptr [{rid} + OFFSETOF_REGION_B], {B}\n"
					if "dB" in self.globalParameters:
						src += f"\t\tvmovapd {B}, ymmword ptr B;  global\n"
						src += f"\t\tvaddpd {B}, {B}, ymmword ptr dB_\n"
						src += f"\t\tvmovapd ymmword ptr B, {B}\n"
				if not batch4 and regi != "rdx":
					src += "\t\t; done?\n"
					src += "\t\tdec rcx\n"
					src += "\t\tjz TAIL_END\n\n"
			if batch4:
				src += "\t\tsub rcx, 4\n"
				src += "\t\tjmp LOOP_START\n"
				src += "\tLOOP_END:\n\n"
			else:
				src += "\tTAIL_END:\n\n"
		# save PRNG state
		src += "\t; save PRNG state\n"
		src += "\tvmovdqa ymmword ptr [prng_state + (0)*32], ymm12\n"
		src += "\tvmovdqa ymmword ptr [prng_state + (1)*32], ymm13\n"
		src += "\tvmovdqa ymmword ptr [prng_state + (2)*32], ymm14\n"
		src += "\tvmovdqa ymmword ptr [prng_state + (3)*32], ymm15\n\n"
		# epilogue
		src += "\t; epilogue: restore non-volitile registers\n"
		for i in range(10):  # XMM6-15
			src += f"\tvmovdqu xmm{6+i}, xmmword ptr [rbp - ({i+1})*16]\n"
		src += f"\tmov rsi, qword ptr [rbp - (10)*16 - 8]\n"
		src += "\tadd rsp, (10)*16 + 8  ; (aligned) space for the 10 non-volitile XMM6-15 reg. and RSI\n"
		src += "\tpop rbp\n"
		src += "\tret\n"
		src += "metropolis ENDP\n\n"
		exports.append(("metropolis", False))
		tqdm_proc_update()

		# seed PROC
		src += "; Seeds (or reseeds) the PRNG using rdseed if availbe, otherwise rdtscp."
		src += "; @param (void)\n"
		src += "; @return (void)\n"
		src += "PUBLIC seed\n"
		src += "seed PROC\n"
		if prng.startswith("xoshiro256"):  # TODO: support other PRNGs
			# use hardware entropy for initial seed
			cores = os.cpu_count()
			rot = ceil(log2(cores))
			src += "\trdseed rcx   ; try hardware entropy\n"
			src += "\tjc TSC_END   ; skip timestamp counter (TSC) method on success\n"
			src += "\trdtscp       ; sets edx:eax (TSC) and ecx (processor core). high bits 0ed.\n"
			src += "\tshl rdx, 32  ; reconstruct 64-bit TSC in rax\n"
			src += "\tor rax, rdx\n"
			if rot % 64 == 0:
				src += ";"  # skip rotate right if it would have no effect
			src += f"\tror rcx, {rot}   ; rotate small number to highest order bits (CPU cores = {cores})\n"
			src += "\txor rcx, rax\n"
			src += "\tTSC_END:     ; initial seed is now in rcx. Now SplitMix64.\n"
			for j in range(4):  # column-major b.c. each column represents an independent PRNG channel
				for i in range(4):
					src += "\t_splitmix64 rax, rcx, rdx\n"
					src += f"\tmov qword ptr [prng_state + ({i})*32 + ({j})*8], rax\n"
		src += "\tret\n"
		src += "seed ENDP\n\n"
		exports.append(("seed", False))
		tqdm_proc_update()

		# randomize PROC
		src += "; Randomize the state of all nodes (i.e. kT=\\infty)\n"
		src += "; @param (void)\n"
		src += "; @return (void)\n"
		src += "randomize PROC\n"
		if self.MUTABLE_NODE_COUNT != 0:
			regi = "rcx"
			one = "ymm6"
			lbl_suffix = "RAND"
			# load PRNG state, and other constants
			if prng.startswith("xoshiro256"):  # TODO: support other PRNGs
				src += f"\t; load vectorized PRNG ({prng}) state into YMM12, YMM13, YMM14, YMM15; and load other constants\n"
				src += "\tvmovdqa ymm12, ymmword ptr [prng_state + (0)*32]\n"
				src += "\tvmovdqa ymm13, ymmword ptr [prng_state + (1)*32]\n"
				src += "\tvmovdqa ymm14, ymmword ptr [prng_state + (2)*32]\n"
				src += "\tvmovdqa ymm15, ymmword ptr [prng_state + (3)*32]\n"
			src += f"\t_vones {one}  ; [1.0, 1.0, 1.0, 1.0]\n\n"
			src += f"\tmov {regi}, MUTABLE_NODE_COUNT  ; load mutable nodes array size\n"
			src += f"\t; assert {regi} > 0\n"
			src += f"\tLOOP_START_{lbl_suffix}:\n"
			src += f"\t\tdec {regi}\n\n"
			# pick uniformally random new state for the node
			wxys = "ymm1"  # [u_1, v_1, u_2, v_2] -> [x_1, y_1, x_2, y_2] -> s'
			flux = "ymm2"  # f'
			zmsk = "ymm3"  # comparision bit-mask -> [z_1, 0, z_2, 0]
			s = "ymm4"     # [s_1, s_1, s_2, s_2] where s_i = (u_i)^2 + (v_i)^2
			omega = "ymm5" if "F" in self.allKeys else "ymm1"  # contains the PRNG random float [0, 1.0) incase it goes unused
			padl = " " * (len(regi) + 1 + 6 - len(lbl_suffix))
			MARSAGLIA_START_2 = f"MARSAGLIA_START_2_{lbl_suffix}"
			MARSAGLIA_START_1 = f"MARSAGLIA_START_1_{lbl_suffix}"
			MARSAGLIA_END = f"MARSAGLIA_END_{lbl_suffix}"
			MARSAGLIA_END_LO = f"MARSAGLIA_END_LO_{lbl_suffix}" if "F" in self.allKeys else MARSAGLIA_END  # end with "leftover" omegas
			F = ["G", "F"][int(batch4)]
			S = ["T", "S"][int(batch4)]
			F1 = f"{F}{2*num+1}"
			F2 = f"{F}{2*num+2}"
			S1 = f"{S}{2*num+1}"
			S2 = f"{S}{2*num+2}"
			src += f"\t\t; pick uniformally random new state for node [{regi}] (Marsaglia's method)\n"
			if "F" in self.allKeys:
				src += f"\t\t{MARSAGLIA_START_2}:             {pad}{padl}; 2 vectors, f' -> {flux}, s' -> {wxys}\n"
				src += f"\t\t\t_gen_ws {wxys}, {wxys}, {s}, {one}, ymm10\n"
				src += f"\t\t\tvcmppd {zmsk}, {s}, {one}, 11h          ; {s} < {one}\n"
				src += f"\t\t\tvmovmskpd rax, {zmsk}                   ; rax = 0...bbaa where a = (s_1 < 1.0) and b = (s_2 < 1.0)\n"
				src += f"\t\t\t{F1}:\ttest rax, 0100b                   ; test bit (b)\n"
				src += f"\t\t\t\tjz {F2}                             ; !b -> s_2 >= 1.0\n"
				src += f"\t\t\t\t_calc_xyz {wxys}, {zmsk}, {s}, {one}\n"
				src += f"\t\t\t\tvperm2f128 {flux}, {wxys}, {zmsk}, 31h  ; [x_2, y_2, z_2, 0] = f'\n"
				src += "\t\t\t\ttest rax, 0001b                   ; test bit (a)\n"
				src += f"\t\t\t\tjz {MARSAGLIA_START_1}   {pad}{padl}; !a -> s_1 >= 1.0\n"
				src += f"\t\t\t\tvperm2f128 {wxys}, {wxys}, {zmsk}, 20h  ; [x_1, y_1, z_1, 0] = s'\n"
				src += f"\t\t\t\tjmp {MARSAGLIA_END}\n"
				src += f"\t\t\t{F2}:\ttest rax, 0001b                   ; test bit (a)\n"
				src += f"\t\t\t\tjz {MARSAGLIA_START_2}   {pad}{padl}; !a -> s_1 >= 1.0\n"
				src += f"\t\t\t\t_calc_xyz {wxys}, {zmsk}, {s}, {one}\n"
				src += f"\t\t\t\tvperm2f128 {flux}, {wxys}, {zmsk}, 20h  ; [x_1, y_1, z_1, 0] -> f'\n"
				src += f"\t\t\t\t; jmp {MARSAGLIA_START_1}\n"
			# either no flux. or already haveflux. only need s'
			src += f"\t\t{MARSAGLIA_START_1}:             {pad}{padl}; only 1 vector, s' -> {wxys}\n"
			src += f"\t\t\t_gen_ws {omega}, {wxys}, {s}, {one}, ymm10\n"
			src += f"\t\t\tvcmppd {zmsk}, {s}, {one}, 11h          ; {s} < {one}\n"
			src += f"\t\t\tvmovmskpd rax, {zmsk}                   ; rax = 0...bbaa where a = (s_1 < 1.0) and b = (s_2 < 1.0)\n"
			src += f"\t\t\t{S1}:\ttest rax, 0100b                   ; test bit (b)\n"
			src += f"\t\t\t\tjz {S2}                             ; !b -> s_2 >= 1.0\n"
			src += f"\t\t\t\t_calc_xyz {wxys}, {zmsk}, {s}, {one}\n"
			src += f"\t\t\t\tvperm2f128 {wxys}, {wxys}, {zmsk}, 31h  ; [x_2, y_2, z_2, 0] = s'\n"
			src += f"\t\t\t\tjmp {MARSAGLIA_END_LO}\n"
			src += f"\t\t\t{S2}:\ttest rax, 0001b                   ; test bit (a)\n"
			src += f"\t\t\t\tjz {MARSAGLIA_START_1}   {pad}{padl}; !a -> s_1 >= 1.0\n"
			src += f"\t\t\t\t_calc_xyz {wxys}, {zmsk}, {s}, ymm6\n"
			src += f"\t\t\t\tvperm2f128 {wxys}, {wxys}, {zmsk}, 20h  ; [x_1, y_1, z_1, 0] = s'\n"
			src += f"\t\t{MARSAGLIA_END}:\n"
			# scale by S and F
			spin = wxys
			flux = flux
			coef = "ymm3"   # scalar S or F broadcast, e.g. [S, S, S, S]
			msk = "xmm3"    # Note: vgather mask used before coef. overlap okay
			addr = "xmm4"   # Addresses [&S, &F] IMPORTANT: Can *not* not overlap with dest `sf` nor mask `msk`. Will cause runtime #UD fault!
			omegaY = omega  # pseudo random ω for randomizing 0 <= |f'| < F
			omegaX = omega.replace("y", "x")
			one = one       # "ymm6"
			sf = "xmm6"     # scalars [S, F] packed; OVERLAPS with {one}
			# TODO: (optimization) skip for S=1.0 and/or F=1.0 (Note: S, F >= 0)
			if "F" in self.allKeys:
				src += "\t\t; generate \\omega coef. for randomizing |f'| = \\omega * F\n"
				src += f"\t\t_gen_omega {omega}, {one}, ymm10\n"
				src += f"\t\t{MARSAGLIA_END_LO}:  ; use \"leftover\" \\omega in {omega}\n"
				src += f"\t\t; scale s' ({spin}) and f' ({flux})\n"
				src += f"\t\tlea rax, SFref\n"
				src += f"\t\tmov rsi, {regi}                           {pad}; calculate array offset\n"
				src += f"\t\tshl rsi, 4                             ; mul 16\n"
				src += f"\t\tvmovapd {addr}, xmmword ptr [rax + rsi]  ; pointers (double*[]) to [S, F]\n"
				src += f"\t\txor rax, rax                           ; 0 base for absolute vgather\n"
				src += f"\t\tvpcmpeqq {msk}, {msk}, {msk}              ; load mask (all 1's)\n"
				src += f"\t\tvgatherqpd {sf}, [rax + {addr}], {msk}\n"
				src += f"\t\tvbroadcastsd {coef}, {sf}                ; {coef} = [S, S, S, S]\n"
				src += f"\t\tvmulpd {spin}, {spin}, {coef}                ; scale {spin} by S\n"
				src += f"\t\t_vpermj {sf}, {sf}                     ; [F, S]\n"
				src += f"\t\tvbroadcastsd {coef}, {sf}                ; {coef} = [F, F, F, F]\n"
				src += f"\t\tvmulpd {flux}, {flux}, {coef}                ; scale {flux} by F\n"
				src += f"\t\tvbroadcastsd {coef}, {omegaX}                 ; {coef} = [\\omega[0], \\omega[0], \\omega[0], \\omega[0]]\n"
				src += f"\t\tvmulpd {flux}, {flux}, {coef}                ; scale {flux} by \\omega\n"
			else:
				src += f"\t\t; scale s' ({spin})\n"
				src += f"\t\tlea rax, Sref\n"
				src += f"\t\tmov rax, qword ptr [rax + {regi}*8]    {pad}; pointer (double*) to S\n"
				src += f"\t\tvbroadcastsd {coef}, qword ptr [rax]  ; [S, S, S, S]\n"
				src += f"\t\tvmulpd {spin}, {spin}, {coef}  ; scale {spin} by S\n"
			src += "\n"
			# change the node's state
			temp = "rdx"
			src += "\t\tlea rax, nodes\n"
			src += f"\t\tmov {temp}, {regi}\n"
			if is_pow2(self.SIZEOF_NODE):
				src += f"\t\tshl {temp}, {self.SIZEOF_NODE.bit_length() - 1}  ; mul SIZEOF_NODE ({self.SIZEOF_NODE})\n"
			else:
				src += f"\t\timul {temp}, SIZEOF_NODE\n"
			src += f"\t\tvmovapd [rax + {temp} + OFFSETOF_SPIN], {spin}  {pad}; update s' -> spin\n"
			if "F" in self.allKeys:
				src += f"\t\tvmovapd [rax + {temp} + OFFSETOF_FLUX], {flux}  {pad}; update f' -> flux\n"
			# loop end
			src += f"\t\ttest {regi}, {regi}\n"
			src += f"\t\tjnz LOOP_START_{lbl_suffix}\n"
			src += f"\tLOOP_END_{lbl_suffix}:\n\n"
			# save PRNG state
			src += "\t; save PRNG state\n"
			src += "\tvmovdqa ymmword ptr [prng_state + (0)*32], ymm12\n"
			src += "\tvmovdqa ymmword ptr [prng_state + (1)*32], ymm13\n"
			src += "\tvmovdqa ymmword ptr [prng_state + (2)*32], ymm14\n"
			src += "\tvmovdqa ymmword ptr [prng_state + (3)*32], ymm15\n\n"
		src += "\tret\n"
		src += "randomize ENDP\n\n"
		exports.append(("randomize", False))
		tqdm_proc_update()

		# mutable_state PROC
		self.SIZEOF_RECORD = 0
		src += "; Allocate memory and store mutable state. e.g., nodes, edges, parameters, etc.\n"
		src += "; @param (rcx) void*: allocated memory large enough to store the mutable state.\n"
		src += ";\tstruct mutable_state {\n"
		if self.MUTABLE_NODE_COUNT != 0 and self.SIZEOF_NODE != 0:
			src += f";\t\tstruct node *nodes[MUTABLE_NODE_COUNT];           // {self.MUTABLE_NODE_COUNT} * {self.SIZEOF_NODE}\n"
			self.SIZEOF_RECORD += self.MUTABLE_NODE_COUNT * self.SIZEOF_NODE
		if self.REGION_COUNT != 0 and self.SIZEOF_REGION != 0:
			src += f";\t\tstruct region *regions[REGION_COUNT];             // {self.REGION_COUNT} * {self.SIZEOF_REGION}\n"
			self.SIZEOF_RECORD += self.REGION_COUNT * self.SIZEOF_REGION
		g = []
		if "B" in self.globalKeys:
			g.append("B[4]")
			self.SIZEOF_RECORD += 32
		if "dB" in self.globalKeys:
			g.append("dB[4]")
			self.SIZEOF_RECORD += 32
		if "A" in self.globalKeys:
			g.append("A[4]")
			self.SIZEOF_RECORD += 32
		if any(p in self.globalKeys for p in ["S", "F", "kT", "Je0"]):
			g.append("S, F, kT, Je0")
			self.SIZEOF_RECORD += 32
		if "dKT" in self.globalKeys:
			g.append("_, _, dkT, _")
			self.SIZEOF_RECORD += 32
		if len(g) != 0:
			g_join = ", ".join(g)
			pad = " " * (41 - len(g_join))
			src += f";\t\tdouble {g_join}; {pad}// {32 * len(g)}\n"
		if self.EDGE_COUNT != 0 and self.SIZEOF_EDGE != 0:
			src += f";\t\tstruct edge *edges[EDGE_COUNT];                   // {self.EDGE_COUNT} * {self.SIZEOF_EDGE}\n"
			self.SIZEOF_RECORD += self.EDGE_COUNT * self.SIZEOF_EDGE
		if self.EDGE_REGION_COUNT != 0 and self.SIZEOF_EDGE_REGION != 0:
			src += f";\t\tstruct edge_region *eregions[EDGE_REGION_COUNT];  // {self.EDGE_REGION_COUNT} * {self.SIZEOF_EDGE_REGION}\n"
			self.SIZEOF_RECORD += self.EDGE_REGION_COUNT * self.SIZEOF_EDGE_REGION
		g = []
		if any(p in self.globalKeys for p in ["J", "Je1", "Jee", "b"]):
			g.append("J, Je1, Jee, b")
			self.SIZEOF_RECORD += 32
		if "D" in self.globalKeys:
			g.append("D[4]")
			self.SIZEOF_RECORD += 32
		if len(g) != 0:
			g_join = ", ".join(g)
			pad = " " * (41 - len(g_join))
			src += f";\t\tdouble {g_join};  {pad}// {32 * len(g)}\n"
		src += ";\t}\n"
		src += "; @return (void)\n"
		src += "mutable_state PROC\n"
		src += "\tmov r11, rdi  ; backup non-volitile reg.\n"
		src += "\tmov r10, rsi  ; backup non-volitile reg.\n\n"
		src += "\tmov rdi, rcx  ; destination buffer\n\n"
		# store nodes
		src += "\t; store nodes\n"
		src += "\tmov rsi, OFFSET nodes  ; source\n"
		src += "\tmov rcx, (SIZEOF_NODE / 8) * MUTABLE_NODE_COUNT  ; number of quadwords (i.e. doubles)\n"
		src += "\trep movsq\n\n"
		# store regions
		if self.REGION_COUNT != 0:
			src += "\t; store regions\n"
			src += "\tmov rsi, OFFSET regions  ; source\n"
			src += "\tmov rcx, (SIZEOF_REGION / 8) * REGION_COUNT  ; ; number of quadwords (i.e. doubles)\n"
			src += "\trep movsq\n\n"
		else:
			src += "\t; skip regions\n\n"
		# store global_nodes
		g = []
		if "B"  in self.globalKeys:  g.append("B")
		if "dB" in self.globalKeys:  g.append("dB")
		if "A"  in self.globalKeys:  g.append("A")
		if any(p in self.globalKeys for p in ["S", "F", "kT", "Je0"]):  g.append("S, F, kT, Je0")
		if "dkT" in self.globalKeys: g.append("_, _, dkT, _")
		if len(g) != 0:
			src += "\tmov rsi, OFFSET global_node  ; source\n"
			src += f"\tmov rcx, 4*({len(g)})  ; {', '.join(g)}\n"
			src += "\trep movsq\n\n"
		else:
			src += "\t; skip global_node\n\n"
		# store edges
		if self.EDGE_COUNT != 0 and self.SIZEOF_EDGE != 0:
			src += "\t; store edges\n"
			src += "\tmov rsi, OFFSET edges  ; source\n"
			src += "\tmov rcx, (SIZEOF_EDGE / 8) * EDGE_COUNT  ; number of quqdwords (i.e. doubles)\n"
			src += "\trep movsq\n\n"
		else:
			src += "\t; skip edges\n\n"
		# store edge_regions
		if self.EDGE_REGION_COUNT != 0:
			src += "\tmov rsi, OFFSET edge_regions  ; source\n"
			src += "\tmov rcx, (SIZEOF_EDGE_REGION / 8) * EDGE_REGION_COUNT  ; number of quqdwords (i.e. doubles)\n"
			src += "\trep movsq\n\n"
		else:
			src += "\t; skip edge_regions\n\n"
		# store global_edge
		g = []
		if any(p in self.globalKeys for p in ["J", "Je1", "Jee", "b"]):  g.append("J, Je1, Jee, b")
		if "D" in self.globalKeys:  g.append("D")
		if len(g) != 0:
			src += "\tmov rsi, OFFSET global_edge  ; source\n"
			src += f"\tmov rcx, 4*({len(g)})  ; {', '.join(g)}\n"
			src += "\trep movsq\n\n"
		else:
			src += "\t; skip global_edge\n\n"
		src += "\tmov rsi, r10  ; restore\n"
		src += "\tmov rdi, r11  ; restore\n"
		src += "\tret\n"
		src += "mutable_state ENDP\n\n"
		exports.append(("mutable_state", False))
		tqdm_proc_update()

		# DLL main (for (un)initialization) -- bypass CRT
		src += "; Windows DLL main (for (un)initialization)\n"
		src += "; @param (rcx) hinstDLL\n"
		src += "; @param (rdx) fwdReason: enum 1, 2, 3, or 4\n"
		src += "; @param (r8) lpvReserved\n"
		src += "; @return (rax) bool: success or failure\n"
		src += "PUBLIC DllMain\n"
		src += "DllMain PROC\n"
		src += "\tcmp rdx, 1\n"
		src += "\tje DLL_PROCESS_ATTACH\n"
		src += "\tcmp rdx, 2\n"
		src += "\tje DLL_THREAD_ATTACH\n"
		src += "\tcmp rdx, 3\n"
		src += "\tje DLL_THREAD_DETACH\n"
		src += "\tcmp rdx, 4\n"
		src += "\tje DLL_PROCESS_DETACH\n"
		src += "\txor rax, rax  ; return false (This should never happen!)\n"
		src += "\tret\n\n"
		src += "\tDLL_PROCESS_ATTACH:\n"
		src += f"\t\t; seed PRNG ({prng})\n"
		if prng.startswith("xoshiro256"):  # TODO: support other PRNGs
			if seed is None or len(seed) == 0:
				src += "\t\tcall seed\n\n"
			else:
				src += "\t\t; (skip) seed was given and was expanded at compile time.\n\n"
		# src += "\tmov rcx, 7   ; number of iterations\n"
		# src += "\tsub rsp, 40  ; reserve shadow space\n"
		# src += "\tcall metropolis\n"
		# src += "\tadd rsp, 40  ; free shadow space\n\n"
		# src += "\txor rax, rax  ; return 0\n"
		src += "\tDLL_THREAD_ATTACH:   ; do nothing\n"
		src += "\tDLL_THREAD_DETACH:   ; do nothing\n"
		src += "\tDLL_PROCESS_DETACH:  ; do nothing\n\n"
		src += "\tmov rax, 1  ; return true\n"
		src += "\tret\n"
		src += "DllMain ENDP\n\n"
		tqdm_proc_update()
		if tqdm_proc is not None:  tqdm_proc.close()

		# ---------------------------------------------------------------------
		for symbol, _ in tqdm_(exports, "[Compiling] Writing ASM PUBLIC (exports)"):
			src += f"PUBLIC {symbol}\n"

		src += "END"  # absolute end of ASM file
		return src, exports

	def assemble(self, src: str, exports: list, tool=VisualStudio(), asm: str=None, def_: str=None, obj: str=None, dll: str=None, dir: str=None) -> tuple[str, bool]:
		# ---------------------------------------------------------------------
		def reserve_tempfile(suffix):
			""" Create an empty temp file for later use. """
			fd, path = mkstemp(suffix=suffix, dir=dir)
			os.close(fd)
			return path

		asm_temp, obj_temp, def_temp, dll_temp = False, False, False, False  # bool flags for cleanup
		if asm is None:  asm  = reserve_tempfile(".asm");  asm_temp = True
		if obj is None:  obj  = reserve_tempfile(".obj");  obj_temp = True
		if def_ is None: def_ = reserve_tempfile(".def");  def_temp = True
		if dll is None:  dll  = reserve_tempfile(".dll");  dll_temp = True
		
		# DEBUG: logging
		print("ASM:", asm)
		print("OBJ:", obj)
		print("DEF:", def_)
		print("DLL:", dll)

		try:
			with open(asm, "w", encoding="utf-8") as file:
				file.write(str(src))
			
			with open(def_, "w", encoding="utf-8") as file:
				file.write("EXPORTS\n")
				for symbol, data in exports:
					file.write(symbol)
					if data:
						file.write("\tDATA")
					file.write("\n")
			
			# compile/assemble
			with resources.as_file(resources.files(__package__)) as package_path:
				try:
					tool.assemble(asm, out=obj, include=[str(package_path)])
					if len(self.debug) == 0:
						tool.dlink(obj, out=dll, entry="DllMain", exports=def_)
					else:
						tool.dlink(obj, "ucrt.lib", "legacy_stdio_definitions.lib", out=dll, exports=def_)  # DEBUG
				except CalledProcessError as ex:
					ex.add_note(f"Error running {tool}. Are you sure this version is installed?")
					if dll_temp:  os.remove(dll)  # remove empty .dll
					raise
		
		finally:
			# clean up temp files
			if asm_temp:  os.remove(asm)
			if obj_temp:  os.remove(obj)
			if def_temp:  os.remove(def_)

		return dll, dll_temp

	def compile(self, tool=VisualStudio(), asm: str=None, def_: str=None, obj: str=None, dll: str=None, dir: str=None, copy_config: bool=True, progress_bars: bool=False, pbar_args: dict={}) -> Runtime:
		src, exports = self.precompile(progress_bars=progress_bars, pbar_args=pbar_args)
		dll, dll_temp = self.assemble(src, exports, tool, asm, def_, obj, dll, dir)
		
		# dynamically link to python
		c = self
		if copy_config:
			c = deepcopy(c)
		return Runtime(config=c, dll=dll, delete=dll_temp)
