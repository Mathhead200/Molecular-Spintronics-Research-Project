Three.js (version 0.160.1) modules bundled using https://bundlejs.com/
then modified to store identifiers in window.Three instead of using "export".

File: three.js contains core library (same as: build/three.modual.js)
File: three_a.js contains core library plus all addons (and required dependancies)
      (same as: build/three.modual.js + examples/jsm/Addons.js)

January 23, 2024
Christopher D'Angelo